#!/usr/bin/env python3
"""Create or verify one machine's native Notenv identities."""

from __future__ import annotations

import argparse
import base64
from contextlib import contextmanager
from datetime import datetime, timezone
import fcntl
import hmac
import hashlib
import json
import os
import platform
import re
import secrets
import shutil
import subprocess
import stat
import sys
import tempfile
import time
import urllib.error
import urllib.request
import urllib.parse
from pathlib import Path
from typing import Any, NoReturn


SERVICES = {
    "channel_identity_resource_id": "notenv-channel-identity",
    "age_identity_resource_id": "notenv-machine-age-identity",
    "protected_unlock_resource_id": "notenv-protected-unlock",
}
REQUIRED_CONFIG_STRINGS = (
    "tenant",
    "machine_id",
    "machine_label",
    "account_profile_id",
    "control_url",
    "age_recipient",
    "channel_signing_public_key",
    "command_verification_key",
    *SERVICES,
)
ENROLLMENT_USER_AGENT = "notenv-enroll"
MACOS_CUSTODY_FD: int | None = None


class EnrollmentError(RuntimeError):
    """A redacted machine-enrollment failure."""


class NativeIdentityMissing(EnrollmentError):
    """A native item is confirmed absent; this never permits replacing an enrolled identity."""


def fail(message: str) -> NoReturn:
    raise EnrollmentError(message)


def host_platform() -> str:
    value = platform.system()
    if value == "Darwin":
        return "macos"
    if value == "Linux":
        return "linux"
    fail(f"unsupported platform: {value}")


def default_config_path() -> Path:
    if host_platform() == "macos":
        return Path.home() / "Library/Application Support/notenv/machine-public.json"
    return Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config")) / "notenv/machine-public.json"


def command(
    argv: list[str],
    *,
    input_bytes: bytes | None = None,
    env: dict[str, str] | None = None,
) -> subprocess.CompletedProcess[bytes]:
    try:
        return subprocess.run(
            argv,
            input=input_bytes,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            check=False,
            timeout=30,
            env=env,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise EnrollmentError(f"required native command unavailable: {argv[0]}") from exc


def secret_service_env() -> dict[str, str]:
    env = dict(os.environ)
    if not env.get("DBUS_SESSION_BUS_ADDRESS"):
        bus = Path(f"/run/user/{os.getuid()}/bus")
        if bus.exists():
            env["DBUS_SESSION_BUS_ADDRESS"] = f"unix:path={bus}"
    return env


def start_macos_custody() -> None:
    """The signed owner launches only its adjacent enrollment script, never a shell."""
    global MACOS_CUSTODY_FD
    descriptor = os.environ.pop("NOTENV_CREDENTIAL_FD", None)
    if descriptor is not None:
        if not descriptor.isascii() or not descriptor.isdigit() or int(descriptor) < 3:
            fail("native custody descriptor is invalid")
        MACOS_CUSTODY_FD = int(descriptor)
        return
    script = Path(__file__).resolve()
    helper = script.parents[1] / "app/keychain-write"
    if script.name != "enroll.py" or not helper.is_file():
        fail("macOS enrollment requires the installed signed native owner")
    os.execv(str(helper), [str(helper), "--enroll", str(script), *sys.argv[1:]])


def native_read_exact(length: int) -> bytearray:
    if MACOS_CUSTODY_FD is None:
        fail("macOS native custody is unavailable")
    value = bytearray()
    try:
        while len(value) < length:
            chunk = os.read(MACOS_CUSTODY_FD, length - len(value))
            if not chunk:
                fail("macOS native custody channel closed")
            value.extend(chunk)
        return value
    except BaseException:
        value[:] = b"\x00" * len(value)
        raise


def native_write_all(value: bytes | bytearray) -> None:
    if MACOS_CUSTODY_FD is None:
        fail("macOS native custody is unavailable")
    remaining = memoryview(value)
    while remaining:
        written = os.write(MACOS_CUSTODY_FD, remaining)
        if written <= 0:
            fail("macOS native custody channel closed")
        remaining = remaining[written:]


def native_identity_request(service: str, account: str, secret: bytearray | None = None) -> bytearray:
    if service not in SERVICES.values() or not re.fullmatch(r"[A-Za-z0-9-]{1,128}", account):
        fail("native identity reference is invalid")
    command_id = 3 + list(SERVICES.values()).index(service) + (3 if secret is not None else 0)
    resource = account.encode("ascii")
    if secret is not None and not 0 < len(secret) < 65536:
        fail("native identity size is invalid")
    native_write_all(bytes([command_id, len(resource)]) + resource)
    if secret is not None:
        native_write_all(len(secret).to_bytes(4, "big"))
        native_write_all(secret)
    status = native_read_exact(1)[0]
    length = 0 if secret is not None else int.from_bytes(native_read_exact(4), "big")
    if length >= 65536 or status != 0 and length != 0:
        fail("macOS native custody response is invalid")
    if status == 3:
        raise NativeIdentityMissing("native identity is missing")
    if status == 4:
        fail("native-custody-locked-or-access-denied")
    if status != 0:
        fail("macOS native custody operation failed")
    return native_read_exact(length)


def load_native(service: str, account: str) -> bytearray:
    if host_platform() == "macos":
        return native_identity_request(service, account)
    attributes = ["notenv-provider", service, "notenv-resource", account]
    environment = secret_service_env()
    result = command(["secret-tool", "lookup", *attributes], env=environment)
    if result.returncode == 1 and not result.stdout and not result.stderr:
        # A dismissed unlock can look like absence. Search without unlocking before creating anything.
        search = command(["secret-tool", "search", "--all", *attributes], env=environment)
        if search.returncode == 0 and not search.stdout and not search.stderr:
            raise NativeIdentityMissing("native identity is missing")
    if result.returncode != 0 or not result.stdout:
        fail("native identity is missing or the credential store is locked")
    return bytearray(result.stdout.rstrip(b"\r\n"))


def store_native(service: str, account: str, secret: bytearray) -> None:
    try:
        if host_platform() == "macos":
            native_identity_request(service, account, secret)
            return
        result = command(
            [
                "secret-tool",
                "store",
                f"--label=Notenv {service}",
                "notenv-provider",
                service,
                "notenv-resource",
                account,
            ],
            input_bytes=bytes(secret),
            env=secret_service_env(),
        )
        if result.returncode != 0:
            fail("Secret Service rejected native identity storage")
    finally:
        secret[:] = b"\x00" * len(secret)


def native_ready(service: str, account: str) -> bool:
    try:
        value = load_native(service, account)
        if not value:
            fail("native identity is empty")
        value[:] = b"\x00" * len(value)
        return True
    except NativeIdentityMissing:
        return False


def selected_openssl() -> str:
    candidates = [os.environ.get("NOTENV_OPENSSL_BIN")]
    if host_platform() == "macos":
        candidates.extend(
            [
                "/opt/homebrew/opt/openssl@3/bin/openssl",
                "/opt/homebrew/bin/openssl",
                "/usr/local/opt/openssl@3/bin/openssl",
            ]
        )
    candidates.append(shutil.which("openssl"))
    for candidate in candidates:
        if not candidate or not os.access(candidate, os.X_OK):
            continue
        try:
            result = command([candidate, "genpkey", "-algorithm", "Ed25519"])
        except EnrollmentError:
            continue
        if result.returncode == 0 and result.stdout:
            return candidate
    fail("an Ed25519-capable OpenSSL is required")


def age_keygen() -> str:
    value = shutil.which("age-keygen")
    if not value:
        fail("age-keygen is required for machine enrollment")
    return value


def uuid_v7() -> str:
    value = bytearray(secrets.token_bytes(16))
    value[:6] = int(time.time() * 1000).to_bytes(6, "big")
    value[6] = (value[6] & 0x0F) | 0x70
    value[8] = (value[8] & 0x3F) | 0x80
    hex_value = value.hex()
    return f"{hex_value[:8]}-{hex_value[8:12]}-{hex_value[12:16]}-{hex_value[16:20]}-{hex_value[20:]}"


def server_origin(value: str, *, control: bool = False) -> str:
    try:
        parsed = urllib.parse.urlsplit(value)
        if (
            parsed.scheme != ("wss" if control else "https")
            or parsed.path not in (("/broker",) if control else ("", "/"))
            or not parsed.hostname or parsed.username is not None or parsed.password is not None
            or parsed.query or parsed.fragment or any(character.isspace() for character in value)
        ):
            fail("server origin is invalid")
        hostname = parsed.hostname
        if ":" in hostname:
            hostname = f"[{hostname}]"
        port = parsed.port
        return f"https://{hostname}" + (f":{port}" if port and port != 443 else "")
    except ValueError:
        fail("server origin is invalid")


def key_fingerprint(public_key: str) -> str:
    try:
        if not isinstance(public_key, str) or not public_key.strip().startswith("-----BEGIN PUBLIC KEY-----") or not public_key.strip().endswith("-----END PUBLIC KEY-----"):
            fail("server command verification key is invalid")
        encoded = public_key.strip().removeprefix("-----BEGIN PUBLIC KEY-----").removesuffix("-----END PUBLIC KEY-----")
        der = base64.b64decode("".join(encoded.split()), validate=True)
        if len(der) != 44 or der[:12] != bytes.fromhex("302a300506032b6570032100"):
            fail("server command verification key must be Ed25519")
        return hashlib.sha256(der).hexdigest()
    except (ValueError, TypeError):
        fail("server command verification key is invalid")


def enrollment_target(args: argparse.Namespace, existing: dict[str, Any] | None) -> dict[str, str]:
    origin = server_origin(args.server) if args.server else (
        server_origin(existing["control_url"], control=True) if existing else ""
    )
    tenant = args.tenant or (str(existing["tenant"]) if existing else "")
    expected = args.server_key_sha256 or (key_fingerprint(existing["command_verification_key"]) if existing else "")
    if not origin or not tenant or not expected:
        fail("first enrollment requires --server, --tenant and --server-key-sha256")
    if not re.fullmatch(r"[a-z0-9]+(?:-[a-z0-9]+)*", tenant):
        fail("enrollment tenant is invalid")
    if not re.fullmatch(r"[a-f0-9]{64}", expected):
        fail("server key fingerprint must be a lowercase SHA-256 hex digest")
    if existing and (
        origin != server_origin(existing["control_url"], control=True) or tenant != existing["tenant"]
    ):
        fail("machine is enrolled to another installation; select a separate config path")
    return {"origin": origin, "tenant": tenant, "key_fingerprint": expected,
            "control_url": "wss://" + origin[len("https://"):] + "/broker"}


def valid_existing_config(value: Any) -> bool:
    return (
        isinstance(value, dict)
        and value.get("schema_version") == 1
        and all(isinstance(value.get(field), str) and value[field] for field in REQUIRED_CONFIG_STRINGS)
        and re.fullmatch(r"[a-z0-9]+(?:-[a-z0-9]+)*", value["tenant"]) is not None
        and str(value.get("control_url", "")).startswith("wss://")
    )


def read_existing(path: Path) -> dict[str, Any] | None:
    if not path.is_file():
        return None
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise EnrollmentError("machine public configuration is invalid") from exc
    if value == {"schema_version": 1, "state": "unenrolled"}:
        return None
    if not valid_existing_config(value):
        fail("machine public configuration is incomplete or invalid")
    server_origin(value["control_url"], control=True)
    return value


def command_verification_key(url: str) -> str:
    request = urllib.request.Request(
        url,
        headers={"Accept": "application/json", "User-Agent": ENROLLMENT_USER_AGENT},
    )
    try:
        with urllib.request.urlopen(request, timeout=30) as response:
            value: Any = json.load(response)
    except (OSError, urllib.error.URLError, json.JSONDecodeError) as exc:
        raise EnrollmentError("server public verification keys are unavailable") from exc
    command_key = value.get("command_verification_key") if isinstance(value, dict) else None
    if not isinstance(command_key, str) or "BEGIN PUBLIC KEY" not in command_key:
        fail("server command verification key is invalid")
    return command_key


def derive_channel_public(openssl: str, encoded: bytearray) -> str:
    try:
        private = bytearray(base64.b64decode(encoded, validate=True))
        arguments = [openssl, "pkey", "-pubout"]
        if not private or private[0] != 0x2D:
            arguments[2:2] = ["-inform", "DER"]
        result = command(arguments, input_bytes=bytes(private))
        if result.returncode != 0 or b"BEGIN PUBLIC KEY" not in result.stdout:
            fail("channel identity cannot derive its public key")
        return result.stdout.decode("ascii")
    finally:
        encoded[:] = b"\x00" * len(encoded)
        if "private" in locals():
            private[:] = b"\x00" * len(private)


def normalized_channel_public(openssl: str, public_key: str) -> bytearray:
    result = command(
        [openssl, "pkey", "-pubin", "-outform", "DER"],
        input_bytes=public_key.encode("ascii"),
    )
    if result.returncode != 0 or not result.stdout:
        fail("channel public key is invalid")
    return bytearray(result.stdout)


def channel_public_matches(openssl: str, encoded: bytearray, expected: str) -> bool:
    derived = normalized_channel_public(openssl, derive_channel_public(openssl, encoded))
    configured = normalized_channel_public(openssl, expected)
    try:
        return hmac.compare_digest(derived, configured)
    finally:
        derived[:] = b"\x00" * len(derived)
        configured[:] = b"\x00" * len(configured)


def derive_age_recipient(age: str, encoded: bytearray) -> str:
    try:
        private = bytearray(base64.b64decode(encoded, validate=True))
        result = command([age, "-y", "-"], input_bytes=bytes(private))
        recipient = result.stdout.decode("ascii").strip()
        if result.returncode != 0 or not re.fullmatch(r"age1[0-9a-z]{20,}", recipient):
            fail("Age identity cannot derive its public recipient")
        return recipient
    finally:
        encoded[:] = b"\x00" * len(encoded)
        if "private" in locals():
            private[:] = b"\x00" * len(private)


def generate_channel_identity(openssl: str) -> bytearray:
    result = command([openssl, "genpkey", "-algorithm", "Ed25519", "-outform", "DER"])
    if result.returncode != 0 or not result.stdout:
        fail("channel identity generation failed")
    return bytearray(base64.b64encode(result.stdout))


def generate_age_identity(age: str) -> bytearray:
    result = command([age])
    identities = [line for line in result.stdout.splitlines() if line and not line.startswith(b"#")]
    if (
        result.returncode != 0
        or len(identities) != 1
        or not re.fullmatch(rb"[A-Z0-9-]{50,100}", identities[0])
    ):
        fail("Age identity generation failed")
    return bytearray(base64.b64encode(identities[0] + b"\n"))


def compact_age_identity(encoded: bytearray) -> tuple[bytearray, bool]:
    """Return the canonical one-line Age identity without exposing or rotating it."""
    identity_prefix = b"-".join((b"AGE", b"SECRET", b"KEY")) + b"-"
    try:
        decoded = bytearray(base64.b64decode(encoded, validate=True))
    except (ValueError, TypeError) as exc:
        fail("Age identity encoding is invalid")
        raise AssertionError from exc
    try:
        identities = [
            line
            for line in decoded.splitlines()
            if re.fullmatch(re.escape(identity_prefix) + rb"[A-Z0-9-]{40,100}", line)
        ]
        if len(identities) != 1:
            fail("Age identity encoding is invalid")
        compact = bytearray(base64.b64encode(identities[0] + b"\n"))
        return compact, compact != encoded
    finally:
        decoded[:] = b"\x00" * len(decoded)


def validate_unlock_identity(encoded: bytearray) -> None:
    try:
        decoded = bytearray(base64.b64decode(encoded, validate=True))
        if len(decoded) != 32:
            fail("protected unlock identity is invalid")
    except (ValueError, TypeError) as exc:
        fail("protected unlock identity is invalid")
        raise AssertionError from exc
    finally:
        encoded[:] = b"\x00" * len(encoded)
        if "decoded" in locals():
            decoded[:] = b"\x00" * len(decoded)


def validate_native_identities(
    existing: dict[str, Any], openssl: str, age: str, *, repair_age_encoding: bool
) -> int:
    channel = load_native(
        SERVICES["channel_identity_resource_id"],
        str(existing["channel_identity_resource_id"]),
    )
    if not channel_public_matches(openssl, channel, str(existing["channel_signing_public_key"])):
        fail("channel identity does not match machine public configuration")

    age_value = load_native(
        SERVICES["age_identity_resource_id"],
        str(existing["age_identity_resource_id"]),
    )
    compact = bytearray()
    changed = False
    try:
        compact, changed = compact_age_identity(age_value)
        if derive_age_recipient(age, bytearray(compact)) != existing["age_recipient"]:
            fail("Age identity does not match machine public configuration")
        if changed:
            if not repair_age_encoding:
                fail("Age identity encoding requires in-place migration")
            store_native(
                SERVICES["age_identity_resource_id"],
                str(existing["age_identity_resource_id"]),
                compact,
            )
            compact = bytearray()
    finally:
        age_value[:] = b"\x00" * len(age_value)
        compact[:] = b"\x00" * len(compact)

    validate_unlock_identity(
        load_native(
            SERVICES["protected_unlock_resource_id"],
            str(existing["protected_unlock_resource_id"]),
        )
    )
    return int(changed)


def write_config(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.parent.chmod(0o700)
    descriptor, name = tempfile.mkstemp(prefix=f".{path.name}.pending-", dir=path.parent)
    pending = Path(name)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8") as output:
            json.dump(value, output, indent=2, sort_keys=True)
            output.write("\n")
            output.flush()
            os.fsync(output.fileno())
        pending.replace(path)
        directory = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(directory)
        finally:
            os.close(directory)
    finally:
        pending.unlink(missing_ok=True)


@contextmanager
def configuration_lock(path: Path):
    """Serialize enrollment and activation without following a lock-file symlink."""
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    parent = path.parent.lstat()
    if not stat.S_ISDIR(parent.st_mode) or parent.st_uid != os.getuid() or parent.st_mode & 0o077:
        fail("machine configuration directory is unsafe")
    descriptor = os.open(path.with_name(path.name + ".lock"), os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW, 0o600)
    try:
        details = os.fstat(descriptor)
        if not stat.S_ISREG(details.st_mode) or details.st_uid != os.getuid() or details.st_nlink != 1 or details.st_mode & 0o077:
            fail("machine configuration lock is unsafe")
        deadline = time.monotonic() + 10
        while True:
            try:
                fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
                break
            except BlockingIOError:
                if time.monotonic() >= deadline:
                    fail("another machine enrollment operation is running")
                time.sleep(0.05)
        yield
    finally:
        os.close(descriptor)


def read_public_record(path: Path) -> dict[str, Any]:
    descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        details = os.fstat(descriptor)
        if not stat.S_ISREG(details.st_mode) or details.st_uid != os.getuid() or details.st_nlink != 1 or details.st_mode & 0o077 or details.st_size > 65536:
            fail("machine replacement public record is unsafe")
        with os.fdopen(descriptor, "r", encoding="utf-8", closefd=False) as source:
            value = json.load(source)
        if not isinstance(value, dict):
            fail("machine replacement public record is invalid")
        return value
    finally:
        os.close(descriptor)


def json_bytes(value: Any) -> bytes:
    return json.dumps(value, ensure_ascii=False, separators=(",", ":")).encode("utf-8")


def identity_crypto(operation: str, key: bytes | bytearray, data: bytes, signature: str = "") -> Any:
    """Use bundled Node crypto through stdin. No private key enters argv or disk."""
    bundled = Path(__file__).resolve().parents[1] / "runtime/bin/node"
    if Path(__file__).name == "enroll.py" and not bundled.is_file():
        fail("machine replacement release runtime is missing")
    node = str(bundled) if bundled.is_file() else shutil.which("node")
    if not node:
        fail("machine replacement requires the release Node runtime")
    script = """
const {sign,verify,createPrivateKey,createPublicKey}=require('node:crypto');
let input='';process.stdin.setEncoding('utf8');process.stdin.on('data',s=>input+=s);
process.stdin.on('end',()=>{try{const p=JSON.parse(input),data=Buffer.from(p.data,'base64');
const key=p.operation==='sign'?createPrivateKey({key:Buffer.from(p.key,'base64'),format:'der',type:'pkcs8'}):createPublicKey(p.key);
if(key.asymmetricKeyType!=='ed25519')throw Error();
process.stdout.write(JSON.stringify(p.operation==='sign'?sign(null,data,key).toString('base64'):verify(null,data,key,Buffer.from(p.signature,'base64'))));
}catch{process.exitCode=1}});
"""
    environment = {name: value for name, value in os.environ.items() if name not in ("NODE_OPTIONS", "NODE_PATH")}
    result = command([node, "--input-type=commonjs", "--eval", script], input_bytes=json_bytes({
        "operation": operation, "key": bytes(key).decode("ascii"),
        "data": base64.b64encode(data).decode("ascii"), "signature": signature,
    }), env=environment)
    if result.returncode:
        fail("machine replacement signature operation failed")
    return json.loads(result.stdout)


def sign_replacement(resource: str, data: bytes) -> str:
    private = load_native(SERVICES["channel_identity_resource_id"], resource)
    try:
        signature = identity_crypto("sign", private, data)
        if not isinstance(signature, str) or not re.fullmatch(r"[A-Za-z0-9+/]{86}==", signature):
            fail("machine replacement signature is invalid")
        return signature
    finally:
        private[:] = b"\x00" * len(private)


def replacement_signing_bytes(request: dict[str, Any]) -> bytes:
    return json_bytes([
        "notenv-machine-key-replacement-v1", request["server_origin"], request["tenant"], request["deployment"],
        request["operation_id"], request["machine_id"], request["platform"], request["issued_at"], request["expires_at"],
        request["expected"]["age_recipient"], request["expected"]["channel_signing_public_key"],
        request["replacement"]["age_recipient"], request["replacement"]["channel_signing_public_key"],
    ])


def utc_timestamp(seconds: float | None = None) -> str:
    return datetime.fromtimestamp(time.time() if seconds is None else seconds, timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def timestamp_seconds(value: Any) -> float:
    if not isinstance(value, str) or not re.fullmatch(r"\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.\d{1,3})?Z", value):
        fail("machine replacement timestamp is invalid")
    return datetime.fromisoformat(value.replace("Z", "+00:00")).timestamp()


def replacement_config(pending: dict[str, Any]) -> dict[str, Any]:
    return {**pending["expected_config"], **pending["resources"], **pending["request"]["replacement"]}


def replacement_record_path(config: Path) -> Path:
    return config.with_name(config.name + ".replacement.json")


def replacement_result(pending: dict[str, Any], state: str) -> dict[str, Any]:
    request = pending["request"]
    encoded = base64.urlsafe_b64encode(json.dumps(request, sort_keys=True, separators=(",", ":")).encode("utf-8")).decode("ascii").rstrip("=")
    if len(encoded) > 8192:
        fail("machine replacement request is too large")
    return {
        "schema_version": 1, "operation": "replace", "state": state, "ready": state == "activated",
        "operation_id": request["operation_id"], "machine_id": request["machine_id"],
        "enrollment_url": request["server_origin"] + "/machines?replace=" + encoded,
        "reconciliation_required": state == "activated", "values_returned": False,
    }


def replacement_intent(existing: dict[str, Any], deployment: str) -> dict[str, Any]:
    operation, issued = uuid_v7(), time.time()
    return {
        "schema_version": 1, "operation_id": operation, "expected_config": existing,
        "deployment": deployment, "issued_at": utc_timestamp(issued), "expires_at": utc_timestamp(issued + 86400),
        "resources": {field: f"{operation}-{suffix}" for field, suffix in zip(SERVICES, ("channel", "age", "unlock"))},
        "request": None,
    }


def prepare_replacement(args: argparse.Namespace, *, newly_allocated: bool = False) -> dict[str, Any]:
    """Allocate public intent first; retain every existing staged identity on retry."""
    path = replacement_record_path(args.config_path)
    if path.exists() or path.is_symlink():
        pending = read_public_record(path)
        validate_replacement_record(args, pending)
        if pending["request"] is not None:
            validate_native_identities(replacement_config(pending), selected_openssl(), age_keygen(), repair_age_encoding=False)
            return pending
        fresh = newly_allocated
    else:
        if args.confirm_replacement:
            fail("no staged machine replacement exists; use --replace first")
        existing = read_public_record(args.config_path)
        if not valid_existing_config(existing):
            fail("machine replacement requires existing public enrollment")
        target = enrollment_target(args, existing)
        if key_fingerprint(existing["command_verification_key"]) != target["key_fingerprint"]:
            fail("stored server verification key does not match the selected fingerprint")
        if not args.deployment or not re.fullmatch(r"[a-z0-9]+(?:-[a-z0-9]+)*", args.deployment) or len(args.deployment) > 100:
            fail("machine replacement requires --deployment")
        if not re.fullmatch(r"[0-9a-f]{8}-[0-9a-f]{4}-7[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}", existing["machine_id"]):
            fail("machine replacement identity is invalid")
        pending = replacement_intent(existing, args.deployment)
        write_config(path, pending)
        fresh = True
    openssl, age = selected_openssl(), age_keygen()
    generators = (lambda: generate_channel_identity(openssl), lambda: generate_age_identity(age), lambda: bytearray(base64.b64encode(secrets.token_bytes(32))))
    for (field, service), generate in zip(SERVICES.items(), generators):
        resource = pending["resources"][field]
        if fresh:
            # The operation has fresh random resource IDs. Never overwrite a preexisting slot.
            if native_ready(service, resource):
                fail("machine replacement resource already exists")
            store_native(service, resource, generate())
        else:
            try:
                value = load_native(service, resource)
                value[:] = b"\x00" * len(value)
            except NativeIdentityMissing:
                # Only a confirmed absent, unpublished slot permits completion.
                # Locked/denied/corrupt custody is not absence and propagates.
                store_native(service, resource, generate())
    existing = pending["expected_config"]
    request = {
        "schema_version": 1, "operation_id": pending["operation_id"],
        "server_origin": server_origin(existing["control_url"], control=True), "tenant": existing["tenant"],
        "deployment": pending["deployment"], "machine_id": existing["machine_id"],
        "platform": "darwin" if host_platform() == "macos" else "linux",
        "issued_at": pending["issued_at"], "expires_at": pending["expires_at"],
        "expected": {field: existing[field] for field in ("age_recipient", "channel_signing_public_key")},
        "replacement": {
            "channel_signing_public_key": derive_channel_public(openssl, load_native(SERVICES["channel_identity_resource_id"], pending["resources"]["channel_identity_resource_id"])),
            "age_recipient": derive_age_recipient(age, load_native(SERVICES["age_identity_resource_id"], pending["resources"]["age_identity_resource_id"])),
        },
    }
    request["signature"] = sign_replacement(pending["resources"]["channel_identity_resource_id"], replacement_signing_bytes(request))
    pending["request"] = request
    validate_replacement_record(args, pending)
    validate_native_identities(replacement_config(pending), openssl, age, repair_age_encoding=False)
    write_config(path, pending)
    return pending


def validate_replacement_record(args: argparse.Namespace, pending: dict[str, Any]) -> None:
    if set(pending) != {"schema_version", "operation_id", "expected_config", "deployment", "issued_at", "expires_at", "resources", "request"} or pending["schema_version"] != 1:
        fail("machine replacement public record is invalid")
    expected = pending["expected_config"]
    if not valid_existing_config(expected) or not isinstance(pending["resources"], dict) or set(pending["resources"]) != set(SERVICES):
        fail("machine replacement configuration is invalid")
    if not isinstance(pending["operation_id"], str) or not re.fullmatch(r"[0-9a-f]{8}-[0-9a-f]{4}-7[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}", pending["operation_id"]):
        fail("machine replacement operation is invalid")
    if not isinstance(pending["deployment"], str) or not re.fullmatch(r"[a-z0-9]+(?:-[a-z0-9]+)*", pending["deployment"]) or len(pending["deployment"]) > 100:
        fail("machine replacement deployment is invalid")
    for field, suffix in zip(SERVICES, ("channel", "age", "unlock")):
        if pending["resources"][field] != f"{pending['operation_id']}-{suffix}" or pending["resources"][field] == expected[field]:
            fail("machine replacement resources are invalid")
    target = enrollment_target(args, expected)
    if key_fingerprint(expected["command_verification_key"]) != target["key_fingerprint"] or args.deployment and args.deployment != pending["deployment"]:
        fail("machine replacement installation changed")
    issued, expires = timestamp_seconds(pending["issued_at"]), timestamp_seconds(pending["expires_at"])
    if issued > time.time() + 60 or not 0 < expires - issued <= 86400:
        fail("machine replacement window is invalid")
    current = read_public_record(args.config_path)
    request = pending["request"]
    if request is None:
        if current != expected:
            fail("machine configuration changed after replacement staging")
        return
    fields = {"schema_version", "operation_id", "server_origin", "tenant", "deployment", "machine_id", "platform", "issued_at", "expires_at", "expected", "replacement", "signature"}
    if not isinstance(request, dict) or set(request) != fields or request["schema_version"] != 1:
        fail("machine replacement request is invalid")
    for field, value in {
        "operation_id": pending["operation_id"], "server_origin": target["origin"], "tenant": expected["tenant"],
        "deployment": pending["deployment"], "machine_id": expected["machine_id"],
        "platform": "darwin" if host_platform() == "macos" else "linux",
        "issued_at": pending["issued_at"], "expires_at": pending["expires_at"],
        "expected": {key: expected[key] for key in ("age_recipient", "channel_signing_public_key")},
    }.items():
        if request[field] != value:
            fail("machine replacement request context is invalid")
    for keys in (request["expected"], request["replacement"]):
        if not isinstance(keys, dict) or set(keys) != {"age_recipient", "channel_signing_public_key"} or not isinstance(keys["age_recipient"], str) or not re.fullmatch(r"age1[0-9a-z]{20,100}", keys["age_recipient"]):
            fail("machine replacement public keys are invalid")
        key_fingerprint(keys["channel_signing_public_key"])
    if any(request["expected"][field] == request["replacement"][field] for field in request["expected"]):
        fail("machine replacement requires new identities")
    if not isinstance(request["signature"], str) or not re.fullmatch(r"[A-Za-z0-9+/]{86}==", request["signature"]) or identity_crypto("verify", request["replacement"]["channel_signing_public_key"].encode("ascii"), replacement_signing_bytes(request), request["signature"]) is not True:
        fail("machine replacement request signature is invalid")
    if current not in (expected, replacement_config(pending)):
        fail("machine configuration changed after replacement staging")


class NoReplacementRedirects(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, _request, _response, _code, _message, _headers, _url):
        fail("machine replacement status redirect refused")


def replacement_status(origin: str, proof: dict[str, Any]) -> dict[str, Any]:
    request = urllib.request.Request(origin + "/api/cli/machine/replacement/status", data=json_bytes(proof), headers={
        "Content-Type": "application/json", "Accept": "application/json", "User-Agent": ENROLLMENT_USER_AGENT,
    }, method="POST")
    try:
        with urllib.request.build_opener(NoReplacementRedirects()).open(request, timeout=30) as response:
            data = response.read(16385)
        if len(data) > 16384:
            fail("machine replacement status is too large")
        return json.loads(data)
    except (OSError, urllib.error.URLError, ValueError):
        fail("machine replacement status is unavailable; staged identities preserved")


def confirm_replacement(args: argparse.Namespace, pending: dict[str, Any], *, activate: bool = True) -> dict[str, Any]:
    request = pending["request"]
    digest = hashlib.sha256(replacement_signing_bytes(request)).hexdigest()
    proof = {"schema_version": 1, "request": request, "issued_at": utc_timestamp(), "nonce": uuid_v7()}
    proof["signature"] = sign_replacement(pending["resources"]["channel_identity_resource_id"], json_bytes([
        "notenv-machine-key-replacement-status-v1", digest, proof["issued_at"], proof["nonce"],
    ]))
    response = replacement_status(request["server_origin"], proof)
    if response == {"schema_version": 1, "state": "pending", "values_returned": False}:
        return replacement_result(pending, "pending")
    if not isinstance(response, dict) or set(response) != {"schema_version", "state", "receipt", "values_returned"} or response["schema_version"] != 1 or response["state"] != "approved" or response["values_returned"] is not False:
        fail("machine replacement receipt is invalid")
    signed = response["receipt"]
    if not isinstance(signed, dict) or set(signed) != {"payload", "signature"} or not isinstance(signed["payload"], str) or not re.fullmatch(r"[A-Za-z0-9_-]{1,12000}", signed["payload"]) or not isinstance(signed["signature"], str) or not re.fullmatch(r"[A-Za-z0-9+/]{86}==", signed["signature"]):
        fail("machine replacement receipt is invalid")
    payload = base64.urlsafe_b64decode(signed["payload"] + "=" * (-len(signed["payload"]) % 4))
    if identity_crypto("verify", pending["expected_config"]["command_verification_key"].encode("ascii"), payload, signed["signature"]) is not True:
        fail("machine replacement receipt signature is invalid")
    receipt = json.loads(payload)
    expected = {
        "schema_version": 1, "kind": "machine-key-replacement", "request_digest": digest,
        **{field: request[field] for field in ("operation_id", "machine_id", "server_origin", "tenant", "deployment", "replacement")},
        "status_nonce": proof["nonce"],
    }
    if not isinstance(receipt, dict) or set(receipt) != {*expected, "issued_at", "approved_at"} or any(receipt[field] != value for field, value in expected.items()):
        fail("machine replacement receipt context is invalid")
    issued, approved, now = timestamp_seconds(receipt["issued_at"]), timestamp_seconds(receipt["approved_at"]), time.time()
    if abs(issued - now) > 60 or abs(timestamp_seconds(proof["issued_at"]) - now) > 60 or approved > issued + 60 or approved < timestamp_seconds(request["issued_at"]) - 60 or approved >= timestamp_seconds(request["expires_at"]):
        fail("machine replacement receipt is stale or invalid")
    # Re-read under the same enrollment lock immediately before the durable commit.
    validate_replacement_record(args, pending)
    if not activate:
        return replacement_result(pending, "approved")
    config = replacement_config(pending)
    if read_public_record(args.config_path) != config:
        write_config(args.config_path, config)
    if args.restart_service:
        restart_broker()
    return {**replacement_result(pending, "activated"), "confirmation_valid_until": min(issued + 60, timestamp_seconds(proof["issued_at"]) + 60)}


def replace(args: argparse.Namespace) -> dict[str, Any]:
    newly_allocated = renew_replacement(args) if args.renew_replacement else False
    pending = prepare_replacement(args, newly_allocated=newly_allocated)
    result = confirm_replacement(args, pending) if args.confirm_replacement else replacement_result(pending, "staged")
    if args.open and result["state"] != "activated":
        opened = command(["open" if host_platform() == "macos" else "xdg-open", result["enrollment_url"]])
        if opened.returncode:
            fail("protected replacement URL could not be opened")
    return result


def renew_replacement(args: argparse.Namespace) -> bool:
    """Retain the exact public predecessor operation before allocating a new one."""
    path = replacement_record_path(args.config_path)
    pending = read_public_record(path)
    validate_replacement_record(args, pending)
    if pending["request"] is None:
        return False
    validate_native_identities(replacement_config(pending), selected_openssl(), age_keygen(), repair_age_encoding=False)
    # Never trust a saved approval or silently activate as a side effect of renewal.
    confirmation = confirm_replacement(args, pending, activate=False)
    current = read_public_record(args.config_path)
    if confirmation["state"] == "pending" and current != pending["expected_config"]:
        fail("machine replacement is no longer current; recovery required")
    if confirmation["state"] == "approved" and current != replacement_config(pending):
        fail("confirm the approved machine replacement before renewal")
    history = path.with_name(path.name + ".history")
    history.mkdir(mode=0o700, exist_ok=True)
    details = history.lstat()
    if not stat.S_ISDIR(details.st_mode) or details.st_uid != os.getuid() or details.st_mode & 0o077:
        fail("machine replacement recovery directory is unsafe")
    archived = history / (pending["operation_id"] + ".json")
    if archived.exists() or archived.is_symlink():
        if read_public_record(archived) != pending:
            fail("machine replacement recovery record conflicts")
    else:
        write_config(archived, pending)
    # Archive commit precedes replacement. A crash between them retries the same
    # archive rather than overwriting it or losing the recovery record.
    if read_public_record(path) != pending:
        fail("machine replacement changed during renewal")
    args.deployment = pending["deployment"]
    write_config(path, replacement_intent(read_public_record(args.config_path), pending["deployment"]))
    return True


def enrollment_url(ui_origin: str, config: dict[str, Any]) -> str:
    payload = {
        "schema_version": 1,
        "machine_id": config["machine_id"],
        "slug": re.sub(r"[^a-z0-9]+", "-", config["machine_label"].lower()).strip("-"),
        "display_name": config["machine_label"],
        "platform": "darwin" if host_platform() == "macos" else "linux",
        "age_recipient": config["age_recipient"],
        "channel_signing_public_key": config["channel_signing_public_key"],
    }
    encoded = base64.urlsafe_b64encode(json.dumps(payload, separators=(",", ":")).encode()).decode().rstrip("=")
    if len(encoded) > 8192:
        raise EnrollmentError("machine-enrollment-request-too-large")
    return f"{ui_origin.rstrip('/')}/machines?enroll={encoded}"


def restart_broker() -> None:
    if host_platform() == "macos":
        result = command(
            [
                "launchctl",
                "kickstart",
                "-k",
                f"gui/{os.getuid()}/com.ctx9.notenv-broker",
            ]
        )
    else:
        result = command(["systemctl", "--user", "restart", "notenv-broker.service"])
    if result.returncode != 0:
        fail("broker service could not restart after enrollment")


def identity_records(existing: dict[str, Any] | None) -> tuple[str, str, dict[str, str]]:
    machine_id = str(existing["machine_id"]) if existing else uuid_v7()
    account_profile = str(existing["account_profile_id"]) if existing else uuid_v7()
    resources = {
        field: str(existing[field]) if existing else f"{machine_id}-{suffix}"
        for field, suffix in (
            ("channel_identity_resource_id", "channel"),
            ("age_identity_resource_id", "age"),
            ("protected_unlock_resource_id", "unlock"),
        )
    }
    return machine_id, account_profile, resources


def verify(args: argparse.Namespace) -> dict[str, Any]:
    existing = read_existing(args.config_path)
    if not existing:
        fail("machine public configuration is incomplete")
    target = enrollment_target(args, existing)
    if key_fingerprint(existing["command_verification_key"]) != target["key_fingerprint"]:
        fail("stored server verification key does not match the selected fingerprint")
    if args.config_path.stat().st_mode & 0o077:
        fail("machine public configuration permissions are unsafe")
    for field, service in SERVICES.items():
        if not native_ready(service, str(existing[field])):
            fail("native identity is missing or the credential store is locked")
    validate_native_identities(existing, selected_openssl(), age_keygen(), repair_age_encoding=False)
    return {
        "schema_version": 1,
        "ready": True,
        "operation": "verify",
        "machine_id": existing["machine_id"],
        "machine_label": existing["machine_label"],
        "platform": host_platform(),
        "config": str(args.config_path),
        "native_identities": "ready",
        "protected_enrollment": "checked-separately-by-broker-authentication",
        "values_returned": False,
    }


def apply(args: argparse.Namespace) -> dict[str, Any]:
    existing = read_existing(args.config_path)
    target = enrollment_target(args, existing)
    command_key = command_verification_key(target["origin"] + "/api/public-keys")
    if not hmac.compare_digest(key_fingerprint(command_key), target["key_fingerprint"]):
        fail("server command verification key does not match the selected fingerprint")
    label = args.machine_label.strip() or str(existing["machine_label"] if existing else platform.node())
    slug = re.sub(r"[^a-z0-9]+", "-", label.lower()).strip("-")
    if not slug or len(label) > 100:
        fail("machine label is invalid")
    machine_id, account_profile, resources = identity_records(existing)
    openssl = selected_openssl()
    age = age_keygen()
    generators = {
        "channel_identity_resource_id": lambda: generate_channel_identity(openssl),
        "age_identity_resource_id": lambda: generate_age_identity(age),
        "protected_unlock_resource_id": lambda: base64.b64encode(secrets.token_bytes(32)),
    }
    created: list[str] = []
    migrated_identity_count = 0
    if existing:
        if not all(native_ready(service, resources[field]) for field, service in SERVICES.items()):
            fail("enrolled native identity is missing or unavailable")
        migrated_identity_count = validate_native_identities(
            existing,
            openssl,
            age,
            repair_age_encoding=True,
        )
    for field, service in SERVICES.items():
        if existing or native_ready(service, resources[field]):
            continue
        generated = bytearray(generators[field]())
        if not generated:
            fail("native identity generation failed")
        store_native(service, resources[field], generated)
        created.append(field)
    channel_public = derive_channel_public(
        openssl,
        load_native(SERVICES["channel_identity_resource_id"], resources["channel_identity_resource_id"]),
    )
    age_recipient = derive_age_recipient(
        age,
        load_native(SERVICES["age_identity_resource_id"], resources["age_identity_resource_id"]),
    )
    config = {
        "schema_version": 1,
        "tenant": target["tenant"],
        "machine_id": machine_id,
        "machine_label": label,
        "account_profile_id": account_profile,
        "control_url": target["control_url"],
        "age_recipient": age_recipient,
        "channel_signing_public_key": channel_public,
        "command_verification_key": command_key,
        **resources,
    }
    write_config(args.config_path, config)
    if args.restart_service:
        restart_broker()
    url = enrollment_url(target["origin"], config)
    if args.open:
        opener = "open" if host_platform() == "macos" else "xdg-open"
        result = command([opener, url])
        if result.returncode != 0:
            fail("protected enrollment URL could not be opened")
    return {
        "schema_version": 1,
        "ready": True,
        "operation": "apply",
        "changed": bool(created) or existing != config,
        "machine_id": machine_id,
        "machine_label": label,
        "platform": host_platform(),
        "config": str(args.config_path),
        "created_identity_count": len(created),
        "migrated_identity_count": migrated_identity_count,
        "native_identities": "ready",
        "protected_enrollment": "pending" if created or not existing or existing["command_verification_key"] != command_key else "preserved",
        "enrollment_url": url,
        "values_returned": False,
    }


def dry_run(args: argparse.Namespace) -> dict[str, Any]:
    existing = read_existing(args.config_path)
    target = enrollment_target(args, existing)
    # A fresh selection has no identity to inspect. Do not require or unlock a native store to preview it.
    readiness = {field: False for field in SERVICES}
    if existing:
        _, _, resources = identity_records(existing)
        readiness = {
            field: native_ready(service, resources[field])
            for field, service in SERVICES.items()
        }
    return {
        "schema_version": 1,
        "ready": True,
        "operation": "dry-run",
        "platform": host_platform(),
        "config": str(args.config_path),
        "config_ready": existing is not None,
        "native_identities_ready": readiness,
        "native_identities_checked": existing is not None,
        "server": target["origin"],
        "tenant": target["tenant"],
        "would_fetch_public_keys": True,
        "would_restart_service": args.restart_service,
        "would_write_values": False,
        "values_returned": False,
    }


def parser() -> argparse.ArgumentParser:
    result = argparse.ArgumentParser()
    modes = result.add_mutually_exclusive_group()
    modes.add_argument("--dry-run", action="store_true")
    modes.add_argument("--verify", action="store_true")
    modes.add_argument("--replace", action="store_true", help="Stage target-local keys for protected browser approval")
    modes.add_argument("--confirm-replacement", action="store_true", help="Fetch a fresh signed receipt and activate staged keys")
    modes.add_argument("--renew-replacement", action="store_true", help="Retain the previous operation and stage fresh keys after a current-status check")
    result.add_argument("--machine-label", default="")
    result.add_argument("--config-path", type=Path, default=default_config_path())
    result.add_argument("--server", help="HTTPS application origin; required on first enrollment")
    result.add_argument("--tenant", help="Organization slug; required on first enrollment")
    result.add_argument("--deployment", help="Installation deployment slug; required to start replacement")
    result.add_argument("--server-key-sha256", help="Expected Ed25519 SPKI SHA-256 hex fingerprint")
    result.add_argument("--open", action="store_true")
    result.add_argument("--restart-service", action="store_true")
    result.add_argument("--json", action="store_true")
    return result


def main() -> int:
    args = parser().parse_args()
    try:
        if host_platform() == "macos":
            start_macos_custody()
        with configuration_lock(args.config_path):
            payload = replace(args) if args.replace or args.confirm_replacement or args.renew_replacement else dry_run(args) if args.dry_run else verify(args) if args.verify else apply(args)
        if args.json:
            print(json.dumps(payload, sort_keys=True))
        else:
            print(f"Notenv enrollment ready={payload['ready']}")
            if "enrollment_url" in payload:
                print(payload["enrollment_url"])
            if payload.get("operation") == "replace":
                print("Fresh CLI authorization and reconciliation required." if payload["ready"] else "After browser approval, run notenv-enroll --confirm-replacement --restart-service with the same --config-path if specified.")
        return 0
    except (EnrollmentError, OSError, ValueError, subprocess.SubprocessError) as exc:
        payload = {
            "schema_version": 1,
            "ready": False,
            "operation": "replace" if args.replace or args.confirm_replacement or args.renew_replacement else "dry-run" if args.dry_run else "verify" if args.verify else "apply",
            "errors": [str(exc)],
            "values_returned": False,
        }
        print(json.dumps(payload, sort_keys=True) if args.json else f"Notenv enrollment failed: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
