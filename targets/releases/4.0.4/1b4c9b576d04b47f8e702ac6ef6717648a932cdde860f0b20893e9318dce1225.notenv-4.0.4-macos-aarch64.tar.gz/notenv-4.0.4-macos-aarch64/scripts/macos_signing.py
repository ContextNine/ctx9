"""Developer ID verification and explicit isolated signing-store selection."""

from __future__ import annotations

import os
import re
import stat
import subprocess
from pathlib import Path
from typing import Callable, Any


def developer_id_requirement(identifier: str, team: str) -> str:
    if not re.fullmatch(r"[A-Za-z0-9]+(?:[.-][A-Za-z0-9]+)+", identifier) or not re.fullmatch(r"[A-Z0-9]{10}", team):
        raise RuntimeError("macos-signing-selection-invalid")
    return (
        '=anchor apple generic '
        'and certificate 1[field.1.2.840.113635.100.6.2.6] exists '
        'and certificate leaf[field.1.2.840.113635.100.6.1.13] exists '
        f'and certificate leaf[subject.OU] = "{team}" '
        f'and identifier = "{identifier}"'
    )


def isolated_signing_keychain() -> Path:
    """Inspect only public filesystem metadata, never store contents or authority."""
    selected = os.environ.get("NOTENV_MACOS_SIGNING_KEYCHAIN")
    if not selected:
        raise RuntimeError("macos-signing-store-required")
    path = Path(selected)
    try:
        if not path.is_absolute():
            raise ValueError()
        details, parent = path.lstat(), path.parent.lstat()
        if (
            not stat.S_ISREG(details.st_mode) or details.st_uid != os.getuid()
            or details.st_mode & 0o077 or details.st_nlink != 1
            or not stat.S_ISDIR(parent.st_mode) or parent.st_uid != os.getuid()
            or parent.st_mode & 0o077
        ):
            raise ValueError()
        resolved = path.resolve(strict=True)
        if resolved.name.lower() in ("login.keychain", "login.keychain-db", "system.keychain"):
            raise ValueError()
        for ancestor in resolved.parents:
            metadata = ancestor.lstat()
            if metadata.st_uid not in (0, os.getuid()) or not stat.S_ISDIR(metadata.st_mode):
                raise ValueError()
            if metadata.st_mode & 0o022 and not (metadata.st_uid == 0 and metadata.st_mode & stat.S_ISVTX):
                raise ValueError()
    except (OSError, ValueError, RuntimeError):
        raise RuntimeError("macos-signing-store-invalid") from None
    return resolved


def native_signature_details(
    path: Path, identifier: str, team: str,
    *, run: Callable[..., subprocess.CompletedProcess[Any]] | None = None,
) -> dict[str, Any]:
    """Evaluate Apple certificate requirements independently of recorded metadata."""
    invoke = run or subprocess.run
    try:
        invoke(
            ["/usr/bin/codesign", "--verify", "--strict", "--verbose=2", "-R", developer_id_requirement(identifier, team), str(path)],
            check=True, capture_output=True, text=True, timeout=30,
        )
        details = invoke(
            ["/usr/bin/codesign", "-dv", "--verbose=4", str(path)],
            check=True, capture_output=True, text=True, timeout=30,
        ).stderr
        fields = dict(line.split("=", 1) for line in details.splitlines() if "=" in line)
        requirement_output = invoke(
            ["/usr/bin/codesign", "-d", "-r-", str(path)],
            check=True, capture_output=True, text=True, timeout=30,
        ).stdout
        requirement = next(
            (line.removeprefix("designated => ") for line in requirement_output.splitlines() if line.startswith("designated => ")),
            "",
        )
        entitlements = invoke(
            ["/usr/bin/codesign", "-d", "--entitlements", ":-", str(path)],
            check=True, capture_output=True, timeout=30,
        ).stdout
        if (
            fields.get("Identifier") != identifier or fields.get("TeamIdentifier") != team
            or fields.get("Signature") == "adhoc" or not fields.get("CDHash")
            or "(runtime)" not in details or not requirement or entitlements.strip()
        ):
            raise ValueError()
    except (OSError, ValueError, RuntimeError, subprocess.SubprocessError):
        raise RuntimeError("macos-native-signature-invalid") from None
    return {
        "path": path.as_posix(), "identifier": identifier, "team_identifier": team,
        "cdhash": fields["CDHash"], "designated_requirement": requirement,
        "hardened_runtime": True, "entitlements": "none",
    }
