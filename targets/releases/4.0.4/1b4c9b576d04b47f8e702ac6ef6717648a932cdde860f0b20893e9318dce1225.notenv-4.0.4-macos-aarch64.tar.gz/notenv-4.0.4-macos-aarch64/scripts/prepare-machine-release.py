#!/usr/bin/env python3
"""Prepare authenticated machine bytes without executing the downloaded release."""
from __future__ import annotations

import fcntl
import gzip
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import stat
import struct
import subprocess
import sys
import tarfile
import unicodedata
import zlib
from contextlib import contextmanager

# The parent uses Python isolated mode; only its own verified release supplies this module.
sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
from macos_signing import native_signature_details

MAX_ENTRIES = 20_000
MAX_FILE = 536_870_912
MAX_UNPACKED = 2_147_483_648
CHUNK = 65_536


class PreparationError(Exception):
    pass


def require(condition: bool) -> None:
    if not condition:
        raise PreparationError()


def unique_object(pairs):
    value = {}
    for key, item in pairs:
        require(key not in value)
        value[key] = item
    return value


def document(data: bytes, maximum: int):
    require(0 < len(data) <= maximum)
    return json.loads(data.decode("utf-8"), object_pairs_hook=unique_object)


def owned_directory(path: Path, *, create: bool = False) -> None:
    require(path.is_absolute())
    if create:
        path.mkdir(mode=0o700, exist_ok=True)
    info = path.lstat()
    require(stat.S_ISDIR(info.st_mode) and info.st_uid == os.getuid()
            and not info.st_mode & 0o077 and path.resolve() == path)


def owned_file(path: Path):
    info = path.lstat()
    require(stat.S_ISREG(info.st_mode) and info.st_uid == os.getuid()
            and info.st_nlink == 1 and not info.st_mode & 0o077)
    return info


def sync_directory(path: Path) -> None:
    descriptor = os.open(path, os.O_RDONLY)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


@contextmanager
def work_directory(destination: Path, operation_ref: str):
    path = destination / (".prepare-" + operation_ref)
    path.mkdir(mode=0o700)
    try:
        yield path
    finally:
        if path.exists():
            shutil.rmtree(path)


def relative_name(name: str) -> str:
    require(isinstance(name, str) and 0 < len(name.encode("utf-8")) <= 1024)
    require(not any(ord(character) < 32 or ord(character) == 127 for character in name))
    path = PurePosixPath(name)
    require(not path.is_absolute() and path.as_posix() == name and len(path.parts) <= 32)
    require(not any(part in ("", ".", "..") or part.endswith((" ", "."))
                    or ":" in part or "\\" in part or len(part.encode("utf-8")) > 255 for part in path.parts))
    require(unicodedata.normalize("NFC", name) == name)
    return name


class LimitedReader:
    def __init__(self, stream):
        self.stream = stream
        self.total = 0

    def read(self, size):
        require(0 <= size <= 1_048_576)
        value = self.stream.read(size)
        self.total += len(value)
        require(self.total <= MAX_UNPACKED)
        return value


def scan_archive(source, archive_root: str, destination: Path | None):
    """Bound pseudo-headers before stdlib decoding, then copy regular members manually."""
    limits = {"headers": 0, "pax": False}

    class BoundedTarInfo(tarfile.TarInfo):
        def _proc_member(self, archive):
            limits["headers"] += 1
            require(limits["headers"] <= MAX_ENTRIES * 2 and self.size >= 0)
            if self.type == tarfile.XHDTYPE:
                require(self.size <= CHUNK and not limits["pax"])
                limits["pax"] = True
            else:
                require(self.type in (tarfile.REGTYPE, tarfile.AREGTYPE, tarfile.DIRTYPE))
                require(self.size <= MAX_FILE and (self.type != tarfile.DIRTYPE or self.size == 0))
                limits["pax"] = False
            return super()._proc_member(archive)

    declared, aliases, files, captured, executable = set(), {}, {}, {}, set()

    def create_directories(path: Path):
        require(destination is not None)
        current = destination
        for component in path.relative_to(destination).parts:
            current = current / component
            owned_directory(current, create=True)

    with gzip.GzipFile(fileobj=source, mode="rb") as decompressed:
        reader = LimitedReader(decompressed)
        with tarfile.open(fileobj=reader, mode="r|", tarinfo=BoundedTarInfo) as archive:
            for member in archive:
                require(len(declared) < MAX_ENTRIES and member.sparse is None
                        and not member.mode & 0o7000 and set(member.pax_headers) <= {"path"})
                name = relative_name(member.name)
                parts = PurePosixPath(name).parts
                require(parts[0] == archive_root and name not in declared)
                declared.add(name)
                for index in range(1, len(parts) + 1):
                    prefix = "/".join(parts[:index])
                    alias = unicodedata.normalize("NFD", prefix).casefold()
                    require(alias not in aliases or aliases[alias] == prefix)
                    aliases[alias] = prefix
                if len(parts) == 1:
                    require(member.isdir())
                    continue
                relative = "/".join(parts[1:])
                path = destination / relative if destination else None
                if member.isdir():
                    if path:
                        create_directories(path)
                    continue
                require(member.isfile())
                if path:
                    create_directories(path.parent)
                    require(shutil.disk_usage(path.parent).free >= member.size + 536_870_912)
                content = archive.extractfile(member)
                require(content is not None)
                capture_limit = 4_194_304 if relative == "release-files.json" else 65_536 if relative == "install-metadata.json" else 0
                if capture_limit:
                    require(member.size <= capture_limit)
                chunks, size, digest = [], 0, hashlib.sha256()
                output = path.open("xb") if path else None
                try:
                    while chunk := content.read(CHUNK):
                        size += len(chunk)
                        require(size <= member.size)
                        digest.update(chunk)
                        if capture_limit:
                            chunks.append(chunk)
                        if output:
                            output.write(chunk)
                    require(size == member.size)
                    if output:
                        output.flush()
                        os.fchmod(output.fileno(), 0o700 if member.mode & 0o111 else 0o600)
                        os.fsync(output.fileno())
                finally:
                    content.close()
                    if output:
                        output.close()
                files[relative] = digest.hexdigest()
                if capture_limit:
                    captured[relative] = b"".join(chunks)
                if member.mode & 0o111:
                    executable.add(relative)
        # Consume padding/trailers under the same decompression budget.
        while reader.read(CHUNK):
            pass
    require("release-files.json" in captured and "install-metadata.json" in captured)
    manifest = document(captured["release-files.json"], 4_194_304)
    require(isinstance(manifest, dict) and manifest.get("schema_version") == 1
            and isinstance(manifest.get("files"), dict))
    expected = manifest["files"]
    require(0 < len(expected) < MAX_ENTRIES and set(expected) == set(files) - {"release-files.json"})
    for name, digest in expected.items():
        relative_name(name)
        require(isinstance(digest, str) and re.fullmatch(r"[a-f0-9]{64}", digest) is not None
                and digest == files[name])
    return files, executable, document(captured["install-metadata.json"], 65_536)


def verify_tree(root: Path, expected: dict[str, str], executable: set[str]) -> None:
    owned_directory(root)
    seen = set()
    parents = {parent.as_posix() for name in expected for parent in PurePosixPath(name).parents if parent.as_posix() != "."}
    visited = 0
    for directory, directories, names in os.walk(root, followlinks=False):
        visited += len(directories) + len(names)
        require(visited <= MAX_ENTRIES * 2)
        for name in directories:
            path = Path(directory) / name
            require(path.relative_to(root).as_posix() in parents)
            owned_directory(path)
        for name in names:
            path = Path(directory) / name
            relative = path.relative_to(root).as_posix()
            info = owned_file(path)
            require(relative in expected and info.st_size <= MAX_FILE
                    and bool(info.st_mode & 0o100) == (relative in executable))
            digest = hashlib.sha256()
            with path.open("rb") as content:
                while chunk := content.read(CHUNK):
                    digest.update(chunk)
            require(digest.hexdigest() == expected[relative])
            seen.add(relative)
    require(seen == set(expected))


def verify_platform(root: Path, metadata: dict, request: dict, descriptor: int) -> str:
    require(isinstance(metadata, dict))
    operating_system, architecture = ("linux", "x86_64") if request["platform"] == "linux-x64" else ("macos", "aarch64")
    require(metadata.get("schema_version") == 1 and metadata.get("version") == request["version"]
            and metadata.get("source_commit") == request["source_commit"]
            and metadata.get("platform") == operating_system and metadata.get("architecture") == architecture
            and metadata.get("build_identity") == f'notenv-{request["version"]}-{operating_system}-{architecture}')
    native = ["runtime/bin/node", "app/peer-uid"]
    native += ["app/age-decrypt"] if operating_system == "linux" else ["app/keychain-write", "app/encrypted-project-owner"]
    for relative in native:
        path = root / relative
        require(owned_file(path).st_mode & 0o100 != 0)
        with path.open("rb") as content:
            header = content.read(64)
        if operating_system == "linux":
            require(len(header) == 64 and header[:6] == b"\x7fELF\x02\x01"
                    and header[7] in (0, 3) and struct.unpack_from("<H", header, 16)[0] in (2, 3)
                    and struct.unpack_from("<H", header, 18)[0] == 62)
        else:
            require(len(header) == 64 and header[:4] == b"\xcf\xfa\xed\xfe"
                    and struct.unpack_from("<I", header, 4)[0] == 0x0100000C
                    and struct.unpack_from("<I", header, 12)[0] == 2)
    if operating_system == "linux":
        require(request["native_signer_team"] is None)
        return "linux-elf"
    require(sys.platform == "darwin")
    signing = metadata.get("native_signing")
    team = request["native_signer_team"]
    require(isinstance(signing, dict) and signing.get("kind") == "developer-id"
            and signing.get("team_identifier") == team and isinstance(signing.get("binaries"), list))
    expected = {item["path"]: item for item in signing["binaries"]}
    identities = {"app/keychain-write": "com.ctx9.notenv.credential-broker",
                  "app/peer-uid": "com.ctx9.notenv.peer-uid",
                  "app/encrypted-project-owner": "com.ctx9.notenv.project-custody"}
    require(len(expected) == len(signing["binaries"]) and set(expected) == set(identities))

    def command(arguments, **options):
        return subprocess.run(arguments, **options, pass_fds=(descriptor,),
                              env={"PATH": "/usr/bin:/bin", **({"HOME": os.environ["HOME"]} if "HOME" in os.environ else {})})

    for relative, identifier in identities.items():
        observed = native_signature_details(root / relative, identifier, team, run=command)
        observed["path"] = relative
        require(observed == expected[relative])
    return "macos-developer-id"


def main() -> None:
    try:
        request = document(sys.stdin.buffer.read(16_385), 16_384)
        require(set(request) == {"archive", "destination", "sha256", "length", "version", "source_commit", "platform", "native_signer_team", "operation_ref"})
        require(re.fullmatch(r"[a-f0-9]{8}-(?:[a-f0-9]{4}-){3}[a-f0-9]{12}", request["operation_ref"]) is not None)
        require(re.fullmatch(r"[a-f0-9]{64}", request["sha256"]) is not None
                and re.fullmatch(r"[a-f0-9]{40}", request["source_commit"]) is not None
                and re.fullmatch(r"(?:0|[1-9][0-9]{0,9})\.(?:0|[1-9][0-9]{0,9})\.(?:0|[1-9][0-9]{0,9})", request["version"]) is not None
                and type(request["length"]) is int and 0 < request["length"] <= 1_073_741_824
                and request["platform"] in ("linux-x64", "macos-arm64"))
        require(request["native_signer_team"] is None if request["platform"] == "linux-x64"
                else isinstance(request["native_signer_team"], str) and re.fullmatch(r"[A-Z0-9]{10}", request["native_signer_team"]) is not None)
        archive, destination = Path(request["archive"]), Path(request["destination"])
        owned_directory(archive.parent)
        require(archive.name == request["sha256"] + ".archive" and archive.resolve() == archive)
        info = owned_file(archive)
        require(info.st_size == request["length"])
        owned_directory(destination.parent)
        owned_directory(destination, create=True)
        lock = os.open(destination / "lock", os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW, 0o600)
        try:
            lock_info = owned_file(destination / "lock")
            require(os.fstat(lock).st_ino == lock_info.st_ino and os.fstat(lock).st_dev == lock_info.st_dev)
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            target = destination / request["sha256"]
            existing = target.exists() or target.is_symlink()
            if existing:
                owned_directory(target)
                payload = target / "release"
                owned_directory(payload)
            archive_fd = os.open(archive, os.O_RDONLY | os.O_NOFOLLOW)
            with os.fdopen(archive_fd, "rb") as source, work_directory(destination, request["operation_ref"]) as pending:
                initial = os.fstat(source.fileno())
                require(initial.st_ino == info.st_ino and initial.st_dev == info.st_dev and initial.st_size == request["length"])
                digest = hashlib.sha256()
                length = 0
                while chunk := source.read(CHUNK):
                    length += len(chunk)
                    require(length <= request["length"])
                    digest.update(chunk)
                require(length == request["length"] and digest.hexdigest() == request["sha256"])
                source.seek(0)
                if not existing:
                    payload = pending / "release"
                    payload.mkdir(mode=0o700)
                suffix = "linux-x86_64" if request["platform"] == "linux-x64" else "macos-aarch64"
                expected, executable, metadata = scan_archive(source, f'notenv-{request["version"]}-{suffix}', None if existing else payload)
                verify_tree(payload, expected, executable)
                verification = verify_platform(payload, metadata, request, lock)
                final = os.fstat(source.fileno())
                require((final.st_ino, final.st_dev, final.st_size, final.st_mtime_ns, final.st_ctime_ns) ==
                        (initial.st_ino, initial.st_dev, initial.st_size, initial.st_mtime_ns, initial.st_ctime_ns))
                receipt = {"schema_version": 1, "version": request["version"], "source_commit": request["source_commit"],
                           "platform": request["platform"], "archive_sha256": request["sha256"],
                           "release_manifest_sha256": expected["release-files.json"], "metadata_sha256": expected["install-metadata.json"],
                           "files": len(expected), "native_verification": verification, "activation_authorized": False, "values_returned": False}
                if not existing:
                    for directory, _, _ in os.walk(pending, topdown=False):
                        sync_directory(Path(directory))
                    pending.rename(target)
                receipt_path = target / "preparation.json"
                if (target / "preparation.pending").exists() or (target / "preparation.pending").is_symlink():
                    owned_file(target / "preparation.pending")
                    (target / "preparation.pending").unlink()
                descriptor = os.open(target / "preparation.pending", os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
                with os.fdopen(descriptor, "w") as output:
                    json.dump(receipt, output, sort_keys=True)
                    output.write("\n")
                    output.flush()
                    os.fsync(output.fileno())
                (target / "preparation.pending").replace(receipt_path)
                sync_directory(target)
                sync_directory(destination)
                print(json.dumps(receipt))
        finally:
            os.close(lock)
    except (OSError, ValueError, KeyError, TypeError, RuntimeError, PreparationError, tarfile.TarError, EOFError, RecursionError, zlib.error, subprocess.SubprocessError):
        print('{"accepted":false,"failure":"update-preparation-invalid","values_returned":false}', file=sys.stderr)
        raise SystemExit(1) from None


if __name__ == "__main__":
    main()
