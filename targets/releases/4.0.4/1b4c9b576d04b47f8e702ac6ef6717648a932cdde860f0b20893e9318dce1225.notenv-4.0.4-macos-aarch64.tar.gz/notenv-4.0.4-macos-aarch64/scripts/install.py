#!/usr/bin/env python3
"""Install an immutable Notenv machine release."""

from __future__ import annotations

import argparse
import fcntl
import hashlib
import json
import os
import platform
import re
import shutil
import socket
import stat
import subprocess
import sys
import time
import uuid
from contextlib import ExitStack, contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterator
from urllib.parse import urlsplit, urlunsplit
from xml.sax.saxutils import escape as xml_escape

# Keep verified release trees immutable, including imports under Python isolated mode.
sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
from notenv_migration import apply_storage_moves, migrate_linux_metadata, plan_storage_moves
from macos_signing import native_signature_details


COMMAND_TARGETS = {
    "notenv": "bin/notenv",
    "notenv-enroll": "scripts/enroll.py",
}
MACOS_NATIVE_IDENTIFIERS = {
    "app/keychain-write": "com.ctx9.notenv.credential-broker",
    "app/peer-uid": "com.ctx9.notenv.peer-uid",
    "app/encrypted-project-owner": "com.ctx9.notenv.project-custody",
}
ACTIVATION_LOCK_FD: int | None = None
ACTIVATION_LOCK_FDS: tuple[int, ...] = ()


def run_command(arguments: list[str], **options: Any) -> subprocess.CompletedProcess[Any]:
    # Closing the parent descriptor must not release a still-running helper's lock.
    if ACTIVATION_LOCK_FDS:
        options["pass_fds"] = ACTIVATION_LOCK_FDS
    options.setdefault("timeout", 60)
    return subprocess.run(arguments, **options)


def check_owned(path: Path, directory: bool = False) -> None:
    info = path.lstat()
    valid_kind = stat.S_ISDIR(info.st_mode) if directory else stat.S_ISREG(info.st_mode)
    if not valid_kind or info.st_uid != os.getuid() or info.st_mode & 0o077:
        raise RuntimeError("activation-state-unsafe")
    if not directory and info.st_nlink != 1:
        raise RuntimeError("activation-state-unsafe")


@contextmanager
def activation_lock(data_root: Path, *, mutate: bool) -> Iterator[Path | None]:
    global ACTIVATION_LOCK_FD, ACTIVATION_LOCK_FDS
    parent_descriptor, parent_descriptors = ACTIVATION_LOCK_FD, ACTIVATION_LOCK_FDS
    state = data_root / ".activation"
    if data_root.exists() or data_root.is_symlink():
        root_info = data_root.lstat()
        if not stat.S_ISDIR(root_info.st_mode) or root_info.st_uid != os.getuid() or root_info.st_mode & 0o022:
            raise RuntimeError("activation-state-unsafe")
    if not mutate and not state.exists() and not state.is_symlink():
        yield None
        return
    if mutate:
        data_root.mkdir(parents=True, mode=0o700, exist_ok=True)
        state.mkdir(mode=0o700, exist_ok=True)
    check_owned(state, directory=True)
    path = state / "lock"
    descriptor = os.open(path, os.O_RDWR | os.O_NOFOLLOW | (os.O_CREAT if mutate else 0), 0o600)
    try:
        check_owned(path)
        info = os.fstat(descriptor)
        if info.st_ino != path.lstat().st_ino or info.st_dev != path.lstat().st_dev:
            raise RuntimeError("activation-state-unsafe")
        try:
            fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise RuntimeError("activation-busy") from None
        ACTIVATION_LOCK_FD = descriptor
        ACTIVATION_LOCK_FDS = (*parent_descriptors, descriptor)
        yield state
    finally:
        ACTIVATION_LOCK_FD, ACTIVATION_LOCK_FDS = parent_descriptor, parent_descriptors
        # Do not LOCK_UN or unlink: an inherited child descriptor may still own it.
        os.close(descriptor)


def read_activation(state: Path | None) -> dict[str, Any] | None:
    if state is None:
        return None
    path = state / "operation.json"
    if not path.exists() and not path.is_symlink():
        return None
    check_owned(path)
    if path.stat().st_size > 65536:
        raise RuntimeError("activation-state-invalid")
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (ValueError, OSError):
        raise RuntimeError("activation-state-invalid") from None
    if (
        not isinstance(value, dict)
        or value.get("schema_version") != 1
        or value.get("state") not in ("applying", "incomplete", "complete")
        or not isinstance(value.get("operation_ref"), str)
        or not isinstance(value.get("request"), dict)
        or any(name not in value or value[name] is not None and not isinstance(value[name], str) for name in ("before_current", "before_previous"))
    ):
        raise RuntimeError("activation-state-invalid")
    return value


def write_activation(state: Path, value: dict[str, Any]) -> None:
    write_public_record(state / "operation.json", value)


def write_public_record(path: Path, value: dict[str, Any]) -> None:
    pending = path.with_name(f".{path.name}-{uuid.uuid4().hex}.pending")
    descriptor = os.open(pending, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
            json.dump(value, handle, sort_keys=True)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        pending.replace(path)
        directory = os.open(path.parent, os.O_RDONLY)
        try:
            os.fsync(directory)
        finally:
            os.close(directory)
    finally:
        pending.unlink(missing_ok=True)


def read_public_record(path: Path) -> dict[str, Any]:
    check_owned(path)
    if path.stat().st_size > 65536:
        raise RuntimeError("machine-replacement-public-record-invalid")
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise RuntimeError("machine-replacement-public-record-invalid")
    return value


def handoff_directory(args: argparse.Namespace, release_hash: str) -> Path:
    return args.activation_state / ("machine-replacement-" + release_hash)


def handoff_initial_config(expected: dict[str, Any]) -> dict[str, Any]:
    """The already-approved managed rename changes one exact origin, not installations."""
    result = dict(expected)
    for name in ("control_url", "public_keys_url", "ui_origin"):
        if not isinstance(result.get(name), str):
            continue
        url = urlsplit(result[name])
        if url.hostname == "secrets.ctx9.com":
            if url.username or url.password or url.query or url.fragment:
                raise RuntimeError("rename-machine-origin-invalid")
            result[name] = urlunsplit((url.scheme, "notenv.ctx9.com" + (f":{url.port}" if url.port else ""), url.path, "", ""))
    return result


def handoff_source_config(args: argparse.Namespace) -> Path:
    paths = previous_installation_paths(args)
    return paths["config"] / "machine-public.json" if args.rename_plan is not None and paths is not None else machine_config_path(args.data_root)


def read_machine_handoff(args: argparse.Namespace, info: dict[str, Any], release_hash: str) -> dict[str, Any] | None:
    directory = handoff_directory(args, release_hash)
    if not directory.exists() and not directory.is_symlink():
        return None
    check_owned(directory, directory=True)
    path = directory / "handoff.json"
    if not path.exists() and not path.is_symlink():
        return None
    value = read_public_record(path)
    if set(value) != {"schema_version", "state", "release", "source_config", "expected_config", "deployment"} or value["schema_version"] != 1 or value["state"] not in ("prepared", "complete"):
        raise RuntimeError("machine-replacement-handoff-invalid")
    if value["release"] != {"version": info["version"], "source_commit": info["source_commit"], "manifest_sha256": release_hash}:
        raise RuntimeError("machine-replacement-release-conflict")
    allowed = {str(machine_config_path(args.data_root))}
    previous = previous_installation_paths(args)
    if previous is not None:
        allowed.add(str(previous["config"] / "machine-public.json"))
    expected = value["expected_config"]
    if not isinstance(value["source_config"], str) or value["source_config"] not in allowed or not isinstance(expected, dict) or expected.get("schema_version") != 1 or not isinstance(expected.get("machine_id"), str) or not isinstance(value["deployment"], str):
        raise RuntimeError("machine-replacement-handoff-invalid")
    return value


def prepare_machine_handoff(args: argparse.Namespace, info: dict[str, Any], release_hash: str) -> dict[str, Any]:
    if platform.system() != "Darwin":
        raise RuntimeError("installer-machine-replacement-requires-macos")
    if not args.deployment:
        raise RuntimeError("machine-replacement-deployment-required")
    directory = handoff_directory(args, release_hash)
    directory.mkdir(mode=0o700, exist_ok=True)
    check_owned(directory, directory=True)
    handoff = read_machine_handoff(args, info, release_hash)
    if handoff is None:
        source = handoff_source_config(args)
        public = read_public_record(source)
        if public.get("schema_version") != 1 or not all(isinstance(public.get(name), str) and public[name] for name in ("machine_id", "age_recipient", "channel_signing_public_key", "command_verification_key")):
            raise RuntimeError("machine-replacement-existing-enrollment-required")
        handoff = {"schema_version": 1, "state": "prepared", "release": {"version": info["version"], "source_commit": info["source_commit"], "manifest_sha256": release_hash}, "source_config": str(source), "expected_config": public, "deployment": args.deployment}
        write_public_record(directory / "handoff.json", handoff)
    if handoff["deployment"] != args.deployment:
        raise RuntimeError("machine-replacement-deployment-conflict")
    if handoff["state"] == "complete":
        raise RuntimeError("machine-replacement-handoff-already-complete")
    if read_public_record(handoff_source_config(args)) != handoff["expected_config"]:
        raise RuntimeError("machine-replacement-source-config-changed")
    candidate = directory / "machine-public.json"
    if not candidate.exists() and not candidate.is_symlink():
        write_public_record(candidate, handoff_initial_config(handoff["expected_config"]))
    receipt = value_free_command([
        "/usr/bin/python3", str(release_root() / "scripts/enroll.py"), "--renew-replacement" if args.renew_machine_replacement else "--replace", "--deployment", args.deployment,
        "--config-path", str(candidate), "--json",
    ], "machine-replacement-staging-failed-current-release-preserved")
    if receipt.get("state") != "staged" or receipt.get("machine_id") != handoff["expected_config"]["machine_id"] or not isinstance(receipt.get("enrollment_url"), str):
        raise RuntimeError("machine-replacement-staging-response-invalid")
    return {**receipt, "candidate_config": str(candidate)}


def confirm_machine_handoff(args: argparse.Namespace, release: Path, info: dict[str, Any], release_hash: str) -> dict[str, Any] | None:
    if platform.system() != "Darwin":
        return None
    handoff = read_machine_handoff(args, info, release_hash)
    if handoff is None or handoff["state"] == "complete":
        return None
    directory = handoff_directory(args, release_hash)
    candidate = directory / "machine-public.json"
    receipt = value_free_command([
        "/usr/bin/python3", str(release / "scripts/enroll.py"), "--confirm-replacement",
        "--config-path", str(candidate), "--json",
    ], "machine-replacement-confirmation-failed-current-release-preserved")
    if receipt.get("state") != "activated" or receipt.get("ready") is not True or receipt.get("machine_id") != handoff["expected_config"]["machine_id"]:
        raise RuntimeError("machine-replacement-browser-approval-required")
    accepted = read_public_record(candidate)
    unchanged = handoff_initial_config(handoff["expected_config"])
    changed_fields = {"age_recipient", "channel_signing_public_key", "channel_identity_resource_id", "age_identity_resource_id", "protected_unlock_resource_id"}
    if set(accepted) != set(unchanged) or any(accepted[name] != value for name, value in unchanged.items() if name not in changed_fields) or any(not isinstance(accepted.get(name), str) or not accepted[name] or accepted[name] == unchanged.get(name) for name in changed_fields):
        raise RuntimeError("machine-replacement-candidate-config-invalid")
    # No installation state is switched by native confirmation: it activated only
    # the separate public candidate. Commit that candidate during installation.
    replacement = {"handoff": handoff, "accepted": accepted, "confirmation_valid_until": receipt.get("confirmation_valid_until")}
    assert_handoff_fresh(replacement)
    return replacement


def assert_handoff_fresh(replacement: dict[str, Any]) -> None:
    deadline = replacement["confirmation_valid_until"]
    now = time.time()
    if isinstance(deadline, bool) or not isinstance(deadline, (int, float)) or not now < deadline <= now + 60:
        raise RuntimeError("machine-replacement-confirmation-expired-repeat-installer")


def commit_machine_handoff(args: argparse.Namespace, replacement: dict[str, Any]) -> None:
    destination = machine_config_path(args.data_root)
    lock = destination.with_name(destination.name + ".lock")
    descriptor = os.open(lock, os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW, 0o600)
    try:
        check_owned(lock)
        try:
            fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise RuntimeError("machine-enrollment-busy") from None
        current = read_public_record(destination)
        if current not in (replacement["handoff"]["expected_config"], replacement["accepted"]):
            raise RuntimeError("machine-replacement-source-config-changed")
        if current != replacement["accepted"]:
            assert_handoff_fresh(replacement)
            write_public_record(destination, replacement["accepted"])
    finally:
        os.close(descriptor)


def activation_target(data_root: Path, name: str) -> str | None:
    link = data_root / name
    if not link.is_symlink():
        if link.exists():
            raise RuntimeError("activation-link-unsafe")
        return None
    target = link.resolve()
    if target.parent != (data_root / "versions").resolve() or not target.is_dir():
        raise RuntimeError("activation-link-unsafe")
    return str(target)


def begin_activation(args: argparse.Namespace, state: Path, operation: str, info: dict[str, Any], release_hash: str) -> tuple[dict[str, Any], bool]:
    request = {
        "operation": operation,
        "version": info["version"],
        "source_commit": info["source_commit"],
        "release_manifest_sha256": release_hash,
        "bin_dir": str(args.bin_dir.resolve()),
        "service_path": str(args.service_path.absolute()),
        "service_mode": args.service_mode,
    }
    if getattr(args, "updates_manager", None) is not None:
        request["updates_manager"] = args.updates_manager
    if getattr(args, "provision_update_trust", False):
        request["provision_update_trust"] = True
    if getattr(args, "broker_admission", False):
        request["broker_admission"] = True
        request["drain_timeout"] = args.drain_timeout
    if getattr(args, "update_descriptor", None):
        request["update_descriptor_sha256"] = args.update_descriptor
        request["update_trigger"] = args.update_trigger
    if getattr(args, "update_coordinator", None):
        request["update_coordinator_ref"] = args.update_coordinator
    if getattr(args, "rename_plan", None):
        request["rename_identity"] = args.rename_plan["identity"]
        request["rename_paths"] = {name: str(path) for name, path in previous_installation_paths(args).items()}
    previous = read_activation(state)
    resume_admission = getattr(args, "resume_admission", None)
    if resume_admission and (previous is None or previous["state"] == "complete"):
        raise RuntimeError("update-admission-operation-mismatch")
    if previous and previous["state"] != "complete":
        if previous["request"] != request:
            raise RuntimeError("activation-request-conflict")
        if request.get("broker_admission") is True and previous.get("effects_state") == "started":
            validate_admission_resume(args, previous, resume_admission)
        elif resume_admission:
            raise RuntimeError("update-admission-resume-phase-invalid")
        elif previous["state"] == "applying":
            raise RuntimeError("activation-outcome-unknown: establish prior owner and helper exit before recovery")
        for name in ("before_current", "before_previous"):
            target = previous[name]
            if target is not None and Path(target).parent != (args.data_root / "versions").resolve():
                raise RuntimeError("activation-state-invalid")
        value, resumed = previous, True
    else:
        value = {
            "schema_version": 1,
            "operation_ref": str(uuid.uuid4()),
            "request": request,
            "before_current": activation_target(args.data_root, "current"),
            "before_previous": activation_target(args.data_root, "previous"),
            "state": "applying",
            "rename_complete": bool(previous and previous.get("rename_complete")),
            **({"effects_state": "not-started"} if getattr(args, "broker_admission", False) else {}),
        }
        if getattr(args, "rename_plan", None):
            value["rename"] = args.rename_plan
        resumed = False
    value["state"] = "applying"
    value["resumed"] = resumed
    write_activation(state, value)
    return value, resumed


def validate_admission_resume(args: argparse.Namespace, transaction: dict[str, Any], operation_ref: str | None) -> None:
    """Forward recovery only, under the original kernel lock and exact archive/request."""
    if not operation_ref:
        raise RuntimeError("update-admission-resume-required")
    if (operation_ref != transaction["operation_ref"] or transaction.get("rename")
        or transaction.get("machine_replacement") or args.rename_plan is not None):
        raise RuntimeError("update-admission-operation-mismatch")
    versions = (args.data_root / "versions").resolve()
    for name in ("before_current", "before_previous"):
        target = transaction[name]
        if target is not None:
            if Path(target).parent != versions or Path(target).resolve() != Path(target):
                raise RuntimeError("activation-state-invalid")
            verify_release(Path(target))
            verify_native_signing(Path(target), metadata(Path(target)))
    target = str(versions / transaction["request"]["version"])
    current = activation_target(args.data_root, "current")
    previous = activation_target(args.data_root, "previous")
    allowed = {(transaction["before_current"], transaction["before_previous"])}
    if target != transaction["before_current"]:
        allowed.update({(transaction["before_current"], transaction["before_current"]),
                        (target, transaction["before_current"])})
    if (current, previous) not in allowed:
        raise RuntimeError("update-admission-recovery-links-conflict")
    if transaction["request"].get("update_descriptor_sha256"):
        validate_update_authorization(args, transaction, transaction.get("authorization"), transaction.get("authorized_effects_at"))


def admission_profile(args: argparse.Namespace) -> dict[str, Any]:
    for directory in (args.data_root / "updates", args.data_root / "updates/settings"):
        check_owned(directory, directory=True)
        if directory.resolve() != directory:
            raise RuntimeError("update-admission-profile-invalid")
    path = args.data_root / "updates/settings/installation.json"
    check_owned(path)
    if path.stat().st_size > 262144:
        raise RuntimeError("update-admission-profile-invalid")
    value = json.loads(path.read_text(encoding="utf-8"))
    if (not isinstance(value, dict) or value.get("schema_version") != 1
        or value.get("installation_root") != str(args.data_root.resolve())
        or value.get("manager") not in ("standalone", "fleet")
        or value.get("kind") not in ("installed", "candidate")):
        raise RuntimeError("update-admission-profile-invalid")
    try:
        uuid.UUID(value["installation_id"])
    except (KeyError, ValueError, TypeError, AttributeError):
        raise RuntimeError("update-admission-profile-invalid") from None
    if value["kind"] == "candidate":
        candidate = os.environ.get("NOTENV_CANDIDATE_ROOT")
        if (os.environ.get("NODE_ENV") != "development" or not candidate
            or Path(candidate).resolve() / "state" != args.data_root.resolve()):
            raise RuntimeError("update-admission-candidate-denied")
        marker = Path(candidate) / "candidate.json"
        check_owned(marker)
        if marker.stat().st_size > 4096 or json.loads(marker.read_text()) != {"schema_version": 1, "purpose": "notenv-candidate"}:
            raise RuntimeError("update-admission-candidate-denied")
    return value


def broker_admission_rpc(method: str, request: dict[str, Any]) -> dict[str, Any]:
    """Public management IPC only, inside the same private owner socket scope as the CLI."""
    runtime = os.environ.get("NOTENV_RUNTIME_ROOT") or os.environ.get("XDG_RUNTIME_DIR") or (
        os.environ.get("TMPDIR") if platform.system() == "Darwin" else None)
    if not runtime:
        raise RuntimeError("update-admission-socket-unavailable")
    parent = Path(runtime).resolve(strict=True)
    check_owned(parent, directory=True)
    path = parent / "notenv.sock"
    info = path.lstat()
    if not stat.S_ISSOCK(info.st_mode) or info.st_uid != os.getuid() or info.st_mode & 0o077 or info.st_nlink != 1:
        raise RuntimeError("update-admission-socket-unsafe")
    body = {"schema_version": 2, "method": method, "request": request}
    with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as connection:
        connection.settimeout(330 if method == "broker-update-admission" and request.get("operation") == "authorize" else 5)
        connection.connect(str(path))
        connection.sendall(json.dumps(body, separators=(",", ":")).encode() + b"\n")
        content = bytearray()
        while True:
            part = connection.recv(8192)
            if not part:
                break
            content.extend(part)
            if len(content) > 65536:
                raise RuntimeError("update-admission-response-invalid")
    if content.count(b"\n") != 1 or not content.endswith(b"\n"):
        raise RuntimeError("update-admission-response-invalid")
    value = json.loads(content)
    if (not isinstance(value, dict) or value.get("schema_version") != 2 or value.get("status") != "ok"
        or value.get("method") != method or not isinstance(value.get("response"), dict)
        or value["response"].get("values_returned") is not False):
        raise RuntimeError("update-admission-request-refused")
    return value["response"]


def broker_update_identity(args: argparse.Namespace, profile: dict[str, Any]) -> dict[str, Any]:
    result = broker_admission_rpc("cli-machine-update", {"operation": "status"})
    if result.get("installation_id") != profile["installation_id"]:
        raise RuntimeError("update-admission-installation-mismatch")
    if profile["kind"] == "installed":
        expected = metadata((args.data_root / "current").resolve())
        if result.get("current_version") != expected["version"] or result.get("distribution") != "installed":
            raise RuntimeError("update-admission-installation-mismatch")
    elif result.get("distribution") != "candidate":
        raise RuntimeError("update-admission-installation-mismatch")
    return result


def await_broker_update_identity(args: argparse.Namespace, profile: dict[str, Any]) -> dict[str, Any]:
    """A service-manager restart completes before the verified broker opens IPC."""
    deadline = time.monotonic() + 15
    while True:
        try:
            return broker_update_identity(args, profile)
        except (OSError, ValueError, RuntimeError):
            if time.monotonic() >= deadline:
                raise RuntimeError("update-broker-readiness-failed") from None
            time.sleep(0.2)


def prepare_broker_admission(args: argparse.Namespace, previous: dict[str, Any] | None) -> None:
    if activation_target(args.data_root, "current") is None or args.rename_plan is not None:
        raise RuntimeError("update-admission-existing-installation-required")
    profile = admission_profile(args)
    status = broker_update_identity(args, profile).get("activation_admission", {})
    if not isinstance(status, dict):
        raise RuntimeError("update-admission-response-invalid")
    # Reconcile the previous completed marker before a new journal replaces its proof.
    if status.get("state") != "open" and not (
        previous and previous["state"] != "complete" and status.get("operation_ref") == previous["operation_ref"]):
        raise RuntimeError("update-admission-recovery-required")


def render_service_definition(release: Path, data_root: Path) -> str:
    template = "launchd.plist" if platform.system() == "Darwin" else "systemd.service"
    return ((release / "service" / template).read_text(encoding="utf-8")
        .replace("__CURRENT__", str(data_root / "current"))
        .replace("__CONFIG__", str(machine_config_path(data_root))).replace("__HOME__", str(Path.home()))
        .replace("__SOPS_AGE_KEY_FILE__", "")
        .replace("__UPDATE_PROFILE__", str(data_root / "updates/settings/installation.json"))
        .replace("__UPDATE_ROOT__", str(data_root / "updates")))


def resume_admitted_service(args: argparse.Namespace, transaction: dict[str, Any]) -> None:
    """Restore the exact verified service while the original started operation is locked.

    A stopped broker cannot admit its own recovery. The durable admitted marker,
    original authorization and exact journal instead fence this explicit resume.
    Ordinary activation still requires the live broker before any effects.
    """
    if args.service_mode != "install":
        return
    validate_admission_resume(args, transaction, args.resume_admission)
    current = (args.data_root / "current").resolve()
    verify_release(current)
    verify_native_signing(current, metadata(current))
    verify_macos_custody_before_activation(current, args.data_root, rename=False)
    check_owned(args.service_path)
    config = machine_config_path(args.data_root)
    check_owned(config)
    # The current link can commit before its service definition. Both closures
    # were verified by the exact original transaction's resume validation.
    roots = {current}
    if transaction["before_current"] is not None:
        roots.add(Path(transaction["before_current"]))
    expected = {render_service_definition(release, args.data_root) for release in roots}
    if args.service_path.read_text(encoding="utf-8") not in expected:
        raise RuntimeError("update-admission-recovery-service-conflict")
    install_service(args.data_root / "current", args.data_root, args.service_path, force=True)
    deadline = time.monotonic() + 15
    while True:
        try:
            prepare_broker_admission(args, transaction)
            return
        except (OSError, ValueError, RuntimeError):
            if time.monotonic() >= deadline:
                raise RuntimeError("update-admission-recovery-service-unavailable") from None
            time.sleep(0.2)


def await_broker_admission(args: argparse.Namespace, transaction: dict[str, Any]) -> bool:
    identity = transaction["request"]
    request = {"operation": "begin", "operation_ref": transaction["operation_ref"],
               **{name: identity[name] for name in ("version", "source_commit", "release_manifest_sha256")}}
    deadline = time.monotonic() + args.drain_timeout
    while True:
        result = broker_admission_rpc("broker-update-admission", request)
        if result.get("operation_ref") != transaction["operation_ref"]:
            raise RuntimeError("update-admission-operation-mismatch")
        if result.get("state") == "ready":
            if any(type(result.get(name)) is not int or result[name] != 0 for name in ("active_requests", "sessions", "pending_approvals")):
                raise RuntimeError("update-admission-response-invalid")
            return True
        if result.get("state") != "draining":
            raise RuntimeError("update-admission-recovery-required")
        if time.monotonic() >= deadline:
            return False
        time.sleep(min(0.2, max(0, deadline - time.monotonic())))


def release_broker_admission() -> str:
    try:
        result = broker_admission_rpc("broker-update-admission", {"operation": "status"})
        return "confirmed" if result.get("state") == "open" and result.get("operation_ref") is None else "pending"
    except (OSError, ValueError, RuntimeError):
        return "pending"


def check_update_coordinator(args: argparse.Namespace, previous: dict[str, Any] | None, info: dict[str, Any], release_hash: str) -> dict[str, Any] | None:
    if not args.update_coordinator:
        return None
    profile = admission_profile(args)
    record = read_public_record(args.data_root / "updates/apply/operation.json")
    expected = {"schema_version": 3, "operation_ref": args.update_coordinator, "trigger": args.update_trigger,
                "installation_id": profile["installation_id"], "version": info["version"],
                "source_commit": info["source_commit"], "release_manifest_sha256": release_hash,
                "descriptor_sha256": args.update_descriptor, "values_returned": False}
    if (record.get("values_returned") is not False or any(record.get(name) != value for name, value in expected.items())
        or record.get("state") not in ("invoking", "recovery-required")):
        raise RuntimeError("update-coordinator-conflict")
    bound = record.get("installer_operation_ref")
    if bound is not None and (bound != args.resume_admission or previous is None or previous["operation_ref"] != bound):
        raise RuntimeError("update-coordinator-operation-used")
    if previous and previous["state"] == "complete" and previous["request"].get("update_coordinator_ref") == args.update_coordinator:
        raise RuntimeError("update-coordinator-operation-used")
    return record


def authorization_time(value: Any) -> datetime:
    if not isinstance(value, str) or len(value) > 64 or not value.endswith("Z"):
        raise RuntimeError("update-authorization-invalid")
    result = datetime.fromisoformat(value[:-1] + "+00:00")
    if result.tzinfo != timezone.utc:
        raise RuntimeError("update-authorization-invalid")
    return result


def validate_update_authorization(args: argparse.Namespace, transaction: dict[str, Any], decision: Any, entered_at: Any = None) -> dict[str, Any]:
    profile = admission_profile(args)
    if profile["manager"] != "standalone":
        raise RuntimeError("update-fleet-managed")
    identity = transaction["request"]
    if identity.get("update_trigger") != args.update_trigger:
        raise RuntimeError("update-authorization-invalid")
    expected = {"operation_ref": transaction["operation_ref"], "installation_id": profile["installation_id"],
                "trigger": identity.get("update_trigger"),
                **{name: identity[name] for name in ("version", "source_commit", "release_manifest_sha256")},
                "descriptor_sha256": identity.get("update_descriptor_sha256")}
    if (not isinstance(decision, dict) or set(decision) != set(expected) | {"evidence_sha256", "policy_revision", "authorized_at", "expires_at", "values_returned"}
        or any(decision.get(name) != value for name, value in expected.items())
        or decision["values_returned"] is not False or type(decision["policy_revision"]) is not int
        or not 0 <= decision["policy_revision"] <= 9_007_199_254_740_991
        or not isinstance(decision["evidence_sha256"], str) or not re.fullmatch(r"[a-f0-9]{64}", decision["evidence_sha256"])):
        raise RuntimeError("update-authorization-invalid")
    issued, expires = authorization_time(decision["authorized_at"]), authorization_time(decision["expires_at"])
    entered = authorization_time(entered_at) if entered_at is not None else datetime.now(timezone.utc)
    if not issued <= entered < expires or not 0 < (expires - issued).total_seconds() <= 10:
        raise RuntimeError("update-authorization-expired")
    marker = read_public_record(args.data_root / "updates/settings/activation.json")
    binding = {name: expected[name] for name in ("operation_ref", "version", "source_commit", "release_manifest_sha256")}
    if (marker.get("schema_version") != 3 or marker.get("state") != "admitted"
        or marker.get("installation_id") != profile["installation_id"] or marker.get("binding") != binding
        or marker.get("authorization") != decision):
        raise RuntimeError("update-authorization-not-committed")
    return decision


def authorize_broker_update(args: argparse.Namespace, transaction: dict[str, Any]) -> dict[str, Any]:
    identity = transaction["request"]
    request = {"operation": "authorize", "operation_ref": transaction["operation_ref"],
               "trigger": identity["update_trigger"],
               **{name: identity[name] for name in ("version", "source_commit", "release_manifest_sha256")},
               "descriptor_sha256": args.update_descriptor}
    response = broker_admission_rpc("broker-update-admission", request)
    if response.get("state") != "authorized" or response.get("activation_authorized") is not True:
        raise RuntimeError("update-authorization-refused")
    decision = {name: response.get(name) for name in (
        "operation_ref", "installation_id", "trigger", "version", "source_commit", "release_manifest_sha256",
        "descriptor_sha256", "evidence_sha256", "policy_revision", "authorized_at", "expires_at", "values_returned")}
    return validate_update_authorization(args, transaction, decision)


def defer_before_effects(args: argparse.Namespace, state: Path, transaction: dict[str, Any], reason: str) -> dict[str, Any]:
    if (transaction["request"].get("broker_admission") is not True or transaction.get("effects_state") != "not-started"
        or transaction["state"] == "complete"
        or any(activation_target(args.data_root, name.removeprefix("before_")) != transaction[name] for name in ("before_current", "before_previous"))):
        raise RuntimeError("update-admission-effects-already-started")
    transaction.update(state="complete", outcome="deferred-before-effects", defer_reason=reason)
    write_activation(state, transaction)
    released = release_broker_admission()
    return {"schema_version": 1, "component": "notenv", "operation": "install", "operation_ref": transaction["operation_ref"],
            "state": "deferred", "reason": reason, "ready": False, "changed": False, "mutation_outcome": "not-started",
            "admission_release": released, "target_version": transaction["request"]["version"], "values_returned": False}


def release_root() -> Path:
    return Path(__file__).resolve().parent.parent


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def metadata(root: Path) -> dict[str, Any]:
    value = json.loads((root / "install-metadata.json").read_text(encoding="utf-8"))
    if value.get("schema_version") != 1 or not value.get("version") or not value.get("source_commit"):
        raise RuntimeError("release metadata is invalid")
    return value


def verify_release(root: Path) -> str:
    expected = json.loads((root / "release-files.json").read_text(encoding="utf-8"))
    if expected.get("schema_version") != 1 or not isinstance(expected.get("files"), dict):
        raise RuntimeError("release file manifest is invalid")
    for relative, digest in expected["files"].items():
        path = root / relative
        if not path.is_file() or sha256(path) != digest:
            raise RuntimeError(f"release file verification failed: {relative}")
    return sha256(root / "release-files.json")


def verify_native_signing(root: Path, info: dict[str, Any], *, previous_identity: bool = False) -> None:
    if info.get("platform") != "macos":
        return
    if platform.system() != "Darwin":
        raise RuntimeError("macOS release must be installed on macOS")
    signing = info.get("native_signing")
    if not isinstance(signing, dict) or signing.get("kind") != "developer-id":
        raise RuntimeError("macOS native signing metadata is missing")
    team = signing.get("team_identifier")
    binaries = signing.get("binaries")
    if not isinstance(team, str) or not team or not isinstance(binaries, list):
        raise RuntimeError("macOS native signing metadata is invalid")
    by_path = {
        item.get("path"): item
        for item in binaries
        if isinstance(item, dict) and isinstance(item.get("path"), str)
    }
    identifiers = MACOS_NATIVE_IDENTIFIERS
    project_custody = info.get("macos_project_custody")
    if project_custody is not None and project_custody != "hardware-sealed-v1":
        raise RuntimeError("macOS project custody metadata is invalid")
    if project_custody is None and "app/encrypted-project-owner" not in by_path:
        # A retained predecessor is verified as the complete unit it shipped.
        # New archives declaring project custody must include its signed owner.
        identifiers = {path: identity for path, identity in identifiers.items() if path != "app/encrypted-project-owner"}
    if previous_identity:
        identifiers = {
            "app/keychain-write": "com.ctx9.secret-bindings.credential-broker",
            "app/peer-uid": "com.ctx9.secret-bindings.peer-uid",
        }
    if set(by_path) != set(identifiers):
        raise RuntimeError("macOS native signing inventory is invalid")
    for relative, identifier in identifiers.items():
        expected = by_path[relative]
        path = root / relative
        observed = native_signature_details(path, identifier, team, run=run_command)
        observed["path"] = relative
        if any(expected.get(key) != value for key, value in observed.items()):
            raise RuntimeError(f"macOS native signature verification failed: {relative}")


def default_paths() -> tuple[Path, Path, Path]:
    home = Path.home()
    if platform.system() == "Darwin":
        return (
            home / "Library/Application Support/notenv",
            home / ".local/bin",
            home / "Library/LaunchAgents/com.ctx9.notenv-broker.plist",
        )
    if platform.system() == "Linux":
        data = Path(os.environ.get("XDG_DATA_HOME", home / ".local/share"))
        config = Path(os.environ.get("XDG_CONFIG_HOME", home / ".config"))
        return (
            data / "notenv",
            home / ".local/bin",
            config / "systemd/user/notenv-broker.service",
        )
    raise RuntimeError("unsupported Notenv platform")


def atomic_link(target: Path, link: Path) -> None:
    pending = link.with_name(f".{link.name}.pending-{os.getpid()}")
    pending.unlink(missing_ok=True)
    pending.symlink_to(target)
    pending.replace(link)


def owned_link(path: Path, data_root: Path) -> bool:
    return path.is_symlink() and path.resolve().is_relative_to(data_root.resolve())


def machine_config_path(data_root: Path) -> Path:
    if platform.system() == "Darwin":
        return data_root / "machine-public.json"
    config = Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config"))
    return config / "notenv/machine-public.json"


def ensure_local_config(data_root: Path) -> Path:
    path = machine_config_path(data_root)
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    descriptor = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        details = os.fstat(descriptor)
        if not stat.S_ISDIR(details.st_mode) or details.st_uid != os.getuid() or details.st_mode & 0o022:
            raise RuntimeError("activation-state-unsafe")
        # Older initializers created an owner-controlled but shared-readable directory.
        os.fchmod(descriptor, 0o700)
        if path.exists() or path.is_symlink():
            check_owned(path)
            return path
        write_public_record(path, {"schema_version": 1, "state": "unenrolled"})
        return path
    finally:
        os.close(descriptor)


def previous_installation_paths(args: argparse.Namespace) -> dict[str, Path] | None:
    """Only the canonical predecessor installation participates in this rename."""
    default_data, default_bin, default_service = default_paths()
    if (args.data_root, args.bin_dir, args.service_path) != (default_data.absolute(), default_bin.absolute(), default_service.absolute()):
        return None
    home = Path.home()
    if platform.system() == "Darwin":
        old_data = home / "Library/Application Support/secret-bindings"
        return {
            "data": old_data, "config": old_data, "state": old_data,
            "new_config": args.data_root, "new_state": args.data_root,
            "service": home / "Library/LaunchAgents/com.ctx9.secret-bindings-broker.plist",
        }
    config = Path(os.environ.get("XDG_CONFIG_HOME", home / ".config"))
    state = Path(os.environ.get("XDG_STATE_HOME", home / ".local/state"))
    return {
        "data": Path(os.environ.get("XDG_DATA_HOME", home / ".local/share")) / "secret-bindings",
        "config": config / "secret-bindings", "state": state / "secret-bindings",
        "new_config": config / "notenv", "new_state": state / "notenv",
        "service": config / "systemd/user/secret-bindings-broker.service",
    }


def previous_installation_plan(args: argparse.Namespace, operation: dict[str, Any] | None) -> dict[str, Any] | None:
    if operation and operation.get("rename_complete") is True:
        return None
    paths = previous_installation_paths(args)
    if paths is None or not any(paths[name].exists() for name in ("data", "config", "state")):
        return None
    release = activation_target(paths["data"], "current")
    if release is None:
        raise RuntimeError("rename-previous-release-unavailable")
    manifest = verify_release(Path(release))
    info = metadata(Path(release))
    if not str(info["version"]).startswith("1."):
        raise RuntimeError("rename-previous-release-unsupported")
    verify_native_signing(Path(release), info, previous_identity=True)
    old_operation = read_activation(paths["data"] / ".activation") if (paths["data"] / ".activation").exists() else None
    if old_operation and old_operation["state"] != "complete":
        raise RuntimeError("rename-previous-activation-incomplete")
    for name in ("secret-bindings", "secret-bindings-enroll"):
        command = args.bin_dir / name
        if (command.exists() or command.is_symlink()) and not owned_link(command, paths["data"]):
            raise RuntimeError("rename-previous-command-conflict")
    prior = operation.get("rename") if operation else None
    identity = {
        "source_root": str(paths["data"]), "version": info["version"],
        "source_commit": info["source_commit"], "release_manifest_sha256": manifest,
    }
    if prior is not None:
        if not isinstance(prior, dict) or prior.get("identity") != identity or not isinstance(prior.get("moves"), list):
            raise RuntimeError("rename-request-conflict")
        permitted = {
            (str(paths["config"]), str(paths["new_config"])),
            (str(paths["state"]), str(paths["new_state"])),
        }
        for move in prior["moves"]:
            if not isinstance(move, dict) or not isinstance(move.get("source"), str) or not isinstance(move.get("destination"), str):
                raise RuntimeError("rename-state-invalid")
            source, destination = Path(move["source"]), Path(move["destination"])
            data_entry = source.parent == paths["data"] and destination == args.data_root / source.name and source.name not in {"versions", "current", "previous", ".activation"}
            if (str(source), str(destination)) not in permitted and not data_entry:
                raise RuntimeError("rename-state-invalid")
            if not isinstance(move.get("device"), int) or not isinstance(move.get("inode"), int):
                raise RuntimeError("rename-state-invalid")
        return prior
    config = paths["config"] / "machine-public.json"
    if not config.is_file() or config.is_symlink():
        raise RuntimeError("rename-machine-config-unavailable")
    check_owned(config)
    if config.stat().st_size > 65536:
        raise RuntimeError("rename-machine-config-invalid")
    planned = plan_storage_moves(paths["data"], args.data_root, paths["config"], paths["new_config"], paths["state"], paths["new_state"])
    moves = []
    for source, destination in planned:
        details = source.lstat()
        moves.append({
            "source": str(source), "destination": str(destination),
            "device": details.st_dev, "inode": details.st_ino, "state": "planned",
        })
    return {"identity": identity, "state": "planned", "moves": moves}


def previous_service_active() -> bool:
    if platform.system() == "Darwin":
        command = ["launchctl", "print", f"gui/{os.getuid()}/com.ctx9.secret-bindings-broker"]
    else:
        command = ["systemctl", "--user", "is-active", "--quiet", "secret-bindings-broker.service"]
    return run_command(command, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False).returncode == 0


def process_metadata() -> dict[int, dict[str, Any]]:
    """Executable paths and process birth identities only, never argv or env."""
    processes: dict[int, dict[str, Any]] = {}
    if platform.system() == "Linux":
        for entry in Path("/proc").iterdir():
            if not entry.name.isdigit():
                continue
            try:
                if entry.stat().st_uid != os.getuid():
                    continue
                fields = (entry / "stat").read_text().rsplit(")", 1)[1].split()
                executable = os.readlink(entry / "exe")
                processes[int(entry.name)] = {
                    "pid": int(entry.name), "parent": int(fields[1]),
                    "birth": fields[19], "executable": executable, "state": fields[0],
                }
            except (OSError, ValueError):
                continue
    else:
        result = run_command(["ps", "-axo", "pid=,ppid=,lstart=,comm="], capture_output=True, text=True, check=True)
        for line in result.stdout.splitlines():
            fields = line.split(None, 7)
            if len(fields) == 8:
                processes[int(fields[0])] = {
                    "pid": int(fields[0]), "parent": int(fields[1]),
                    "birth": " ".join(fields[2:7]), "executable": fields[7], "state": "live",
                }
    return processes


def previous_release_processes(root: Path) -> list[dict[str, Any]]:
    processes = process_metadata()
    owned = {pid for pid, process in processes.items() if process["executable"].startswith(str(root) + "/") and process["state"] != "Z"}
    while True:
        added = {pid for pid, process in processes.items() if process["parent"] in owned and process["state"] != "Z"} - owned
        if not added:
            break
        owned |= added
    return [{name: processes[pid][name] for name in ("pid", "birth")} for pid in sorted(owned)]


def recorded_processes_alive(recorded: list[dict[str, Any]]) -> bool:
    current = process_metadata()
    return any(
        process["pid"] in current and current[process["pid"]]["birth"] == process["birth"]
        and current[process["pid"]]["state"] != "Z"
        for process in recorded
    )


def migrate_native_metadata(release: Path, *, dry_run: bool) -> int:
    if platform.system() == "Linux":
        return migrate_linux_metadata(dry_run=dry_run)
    result = run_command(
        [str(release / "app/keychain-write"), "--plan-notenv-metadata" if dry_run else "--migrate-notenv-metadata"],
        check=False, capture_output=True, text=True,
    )
    if result.returncode == 4:
        raise RuntimeError("rename-native-confirmation-required")
    if result.returncode:
        raise RuntimeError("rename-native-metadata-failed")
    try:
        value = json.loads(result.stdout)
    except ValueError:
        raise RuntimeError("rename-native-response-invalid") from None
    if value.get("values_returned") is not False or not isinstance(value.get("changed_items"), int) or value["changed_items"] < 0:
        raise RuntimeError("rename-native-response-invalid")
    return value["changed_items"]


def value_free_command(arguments: list[str], diagnostic: str) -> dict[str, Any]:
    result = run_command(arguments, capture_output=True, text=True, check=False)
    try:
        value = json.loads(result.stdout)
    except ValueError:
        raise RuntimeError(diagnostic) from None
    if result.returncode or not isinstance(value, dict) or value.get("values_returned") is not False:
        raise RuntimeError(diagnostic)
    return value


def verify_macos_custody_before_activation(release: Path, data_root: Path, *, rename: bool) -> None:
    """A new native owner must prove access before changing the running release."""
    if platform.system() != "Darwin":
        return
    if rename:
        # The predecessor trusts a different native subject. Do not stop its
        # broker or enter its password-heavy migration without an accepted handoff.
        raise RuntimeError("native-custody-reenrollment-required")
    config = machine_config_path(data_root)
    if not config.exists():
        return
    public = json.loads(config.read_text(encoding="utf-8"))
    if not public.get("age_recipient") and not public.get("channel_signing_public_key"):
        return
    receipt = value_free_command(
        ["/usr/bin/python3", str(release / "scripts/enroll.py"), "--verify", "--json", "--config-path", str(config)],
        "native-custody-not-ready-current-release-preserved",
    )
    if receipt.get("ready") is not True or receipt.get("machine_id") != public.get("machine_id"):
        raise RuntimeError("native-custody-not-ready-current-release-preserved")


def migrate_previous_installation(args: argparse.Namespace, release: Path, transaction: dict[str, Any]) -> bool:
    rename = transaction.get("rename")
    if rename is None or transaction.get("rename_complete"):
        return False
    paths = previous_installation_paths(args)
    if paths is None or rename["identity"]["source_root"] != str(paths["data"]):
        raise RuntimeError("rename-request-conflict")
    state = args.activation_state
    if rename["state"] == "planned":
        if previous_service_active():
            status = run_command([str(args.bin_dir / "secret-bindings"), "sessions"], capture_output=True, text=True, check=False)
            try:
                sessions = json.loads(status.stdout)
            except ValueError:
                raise RuntimeError("rename-session-status-unavailable") from None
            if status.returncode or sessions.get("schema_version") != 1 or not isinstance(sessions.get("sessions"), list):
                raise RuntimeError("rename-session-status-unavailable")
            if sessions["sessions"]:
                raise RuntimeError("rename-managed-sessions-require-drain")
            if getattr(args, "machine_replacement", None) is not None:
                rename["authorization_before"] = "fresh-login-required"
            else:
                authorization = value_free_command(
                    [str(args.bin_dir / "secret-bindings"), "auth", "status"],
                    "rename-previous-authorization-unavailable",
                )
                rename["authorization_before"] = authorization.get("state")
        rename["processes"] = previous_release_processes(paths["data"])
        rename["state"] = "stopping"
        write_activation(state, transaction)
    if rename["state"] == "stopping":
        if previous_service_active():
            if platform.system() == "Darwin":
                stop = ["launchctl", "bootout", f"gui/{os.getuid()}/com.ctx9.secret-bindings-broker"]
            else:
                stop = ["systemctl", "--user", "disable", "--now", "secret-bindings-broker.service"]
            run_command(stop, capture_output=True, check=True)
        if previous_service_active() or previous_release_processes(paths["data"]) or recorded_processes_alive(rename["processes"]):
            raise RuntimeError("rename-previous-processes-still-running")
        rename["state"] = "native"
        write_activation(state, transaction)
    if rename["state"] == "native":
        if platform.system() == "Darwin":
            if getattr(args, "machine_replacement", None) is None:
                raise RuntimeError("native-custody-reenrollment-required")
            rename["native_changed_items"] = 0
        else:
            rename["native_changed_items"] = migrate_native_metadata(release, dry_run=False)
        rename["state"] = "storage"
        write_activation(state, transaction)
    if rename["state"] == "storage":
        by_source = {entry["source"]: entry for entry in rename["moves"]}
        for entry in rename["moves"]:
            source, destination = Path(entry["source"]), Path(entry["destination"])
            observed = source if source.exists() else destination
            if not observed.exists() or observed.is_symlink():
                raise RuntimeError("rename-storage-step-uncertain")
            details = observed.lstat()
            if (details.st_dev, details.st_ino) != (entry["device"], entry["inode"]):
                raise RuntimeError("rename-storage-step-uncertain")

        def record(source: Path, destination: Path, phase: str) -> None:
            entry = by_source[str(source)]
            if entry["destination"] != str(destination):
                raise RuntimeError("rename-storage-step-uncertain")
            entry["state"] = phase
            write_activation(state, transaction)

        apply_storage_moves([(Path(entry["source"]), Path(entry["destination"])) for entry in rename["moves"]], record=record)
        rename["state"] = "configuration"
        write_activation(state, transaction)
    if rename["state"] == "configuration":
        config_path = machine_config_path(args.data_root)
        check_owned(config_path)
        original = config_path.read_bytes()
        config = json.loads(original)
        if config.get("schema_version") != 1 or not isinstance(config.get("machine_id"), str):
            raise RuntimeError("rename-machine-config-invalid")
        backup = state / "machine-public-before-rename.json"
        if not backup.exists():
            descriptor = os.open(backup, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
            with os.fdopen(descriptor, "wb") as handle:
                handle.write(original)
                handle.flush()
                os.fsync(handle.fileno())
        replacement = getattr(args, "machine_replacement", None)
        if replacement is not None:
            if config not in (replacement["handoff"]["expected_config"], replacement["accepted"]):
                raise RuntimeError("machine-replacement-source-config-changed")
            config = replacement["accepted"]
        config = handoff_initial_config(config)
        if replacement is not None:
            assert_handoff_fresh(replacement)
        write_public_record(config_path, config)
        rename["state"] = "activated"
        write_activation(state, transaction)
    if rename["state"] != "activated":
        raise RuntimeError("rename-state-invalid")
    return True


def finish_previous_installation(args: argparse.Namespace, transaction: dict[str, Any]) -> None:
    rename = transaction.get("rename")
    if rename is None or transaction.get("rename_complete"):
        return
    paths = previous_installation_paths(args)
    if paths is None or rename.get("state") != "activated":
        raise RuntimeError("rename-state-invalid")
    public = json.loads(machine_config_path(args.data_root).read_text())
    if public.get("age_recipient") and public.get("channel_signing_public_key"):
        enrollment = value_free_command(
            [str(args.data_root / "current/scripts/enroll.py"), "--verify", "--json"],
            "rename-native-identity-verification-failed",
        )
        if enrollment.get("ready") is not True or enrollment.get("machine_id") != public["machine_id"]:
            raise RuntimeError("rename-native-identity-verification-failed")
    if rename.get("authorization_before") == "authorized" and not transaction.get("machine_replacement"):
        authorization = value_free_command(
            [str(args.bin_dir / "notenv"), "auth", "status"],
            "rename-authorization-verification-failed",
        )
        if authorization.get("state") != "authorized":
            raise RuntimeError("rename-authorization-verification-failed")
    for name in ("secret-bindings", "secret-bindings-enroll"):
        command = args.bin_dir / name
        if command.is_symlink() and owned_link(command, paths["data"]):
            command.unlink()
        elif command.exists() or command.is_symlink():
            raise RuntimeError("rename-previous-command-conflict")
    if paths["service"].exists():
        if paths["service"].is_symlink():
            raise RuntimeError("rename-previous-service-unsafe")
        archive = paths["data"] / ".activation/previous-service"
        if archive.exists():
            raise RuntimeError("rename-previous-service-conflict")
        paths["service"].rename(archive)
    rename["state"] = "complete"
    transaction["rename_complete"] = True
    write_activation(args.activation_state, transaction)


def service_state() -> bool:
    if platform.system() == "Darwin":
        return run_command(
            ["launchctl", "print", f"gui/{os.getuid()}/com.ctx9.notenv-broker"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            check=False,
        ).returncode == 0
    return run_command(
        ["systemctl", "--user", "is-active", "--quiet", "notenv-broker.service"],
        check=False,
    ).returncode == 0


def ensure_service_directory(path: Path) -> None:
    if path.exists():
        return
    ensure_service_directory(path.parent)
    path.mkdir(mode=0o700)


def install_service(current: Path, data_root: Path, service_path: Path, *, force: bool) -> bool:
    ensure_local_config(data_root)
    rendered = render_service_definition(current, data_root)
    identical = service_path.is_file() and service_path.read_text(encoding="utf-8") == rendered
    if identical and not force and service_state():
        info = service_path.lstat()
        if not stat.S_ISREG(info.st_mode) or info.st_uid != os.getuid() or info.st_nlink != 1:
            raise RuntimeError("service-path-unsafe")
        permissions_changed = stat.S_IMODE(info.st_mode) != 0o600
        service_path.chmod(0o600)
        return permissions_changed
    ensure_service_directory(service_path.parent)
    pending = service_path.with_name(f".{service_path.name}.pending-{os.getpid()}")
    pending.write_text(rendered, encoding="utf-8")
    pending.chmod(0o600)
    pending.replace(service_path)
    if platform.system() == "Darwin":
        domain = f"gui/{os.getuid()}"
        run_command(["launchctl", "bootout", domain, str(service_path)], check=False, capture_output=True)
        if run_command(["launchctl", "bootstrap", domain, str(service_path)], check=False, capture_output=True).returncode:
            raise RuntimeError("launchd activation failed")
        run_command(
            ["launchctl", "kickstart", "-k", f"{domain}/com.ctx9.notenv-broker"],
            check=True,
            capture_output=True,
        )
    else:
        run_command(["systemctl", "--user", "daemon-reload"], check=True, capture_output=True)
        run_command(
            ["systemctl", "--user", "enable", "notenv-broker.service"],
            check=True,
            capture_output=True,
        )
        run_command(["systemctl", "--user", "restart", "notenv-broker.service"], check=True, capture_output=True)
    return True


class UpdateProvisioningError(RuntimeError):
    def __init__(self, detail: dict[str, Any]):
        super().__init__("update-installation-provisioning-failed")
        self.detail = detail


def provisioning_failure(stderr: str | bytes | None) -> dict[str, Any]:
    """Accept only the fixed worker diagnostic; raw child output never leaves this boundary."""
    fallback = {"schema_version": 1, "phase": "unconfirmed", "code": "worker-failed", "values_returned": False}
    phases = {"arguments", "trust-file", "installation-root", "settings", "profile-lock", "existing-profile", "trust", "discovery", "profile-write"}
    codes = {"update-configuration-invalid", "update-path-unsafe", "update-installation-owner-conflict", "update-platform-unsupported", "update-busy", "update-lock-unavailable", "update-recovery-required", "update-signature-trust-invalid", "filesystem-error", "operation-failed"}
    system_codes = {"EACCES", "EPERM", "ENOENT", "ENOSPC", "EIO", "EMFILE", "ENFILE", "EROFS"}
    if not isinstance(stderr, (str, bytes)) or len(stderr) > 4096:
        return fallback
    try:
        value = json.loads(stderr)
    except (ValueError, UnicodeError, RecursionError):
        return fallback
    if (not isinstance(value, dict) or set(value) not in ({"schema_version", "phase", "code", "values_returned"}, {"schema_version", "phase", "code", "system_code", "values_returned"})
            or type(value.get("schema_version")) is not int or value["schema_version"] != 1
            or value.get("values_returned") is not False
            or not isinstance(value.get("phase"), str) or value["phase"] not in phases
            or not isinstance(value.get("code"), str) or value["code"] not in codes
            or "system_code" in value and (not isinstance(value["system_code"], str) or value["system_code"] not in system_codes or value["code"] != "filesystem-error")
            or value["code"] == "filesystem-error" and "system_code" not in value):
        return fallback
    return value


def provision_machine_updates(args: argparse.Namespace, release: Path) -> bool:
    manager = getattr(args, "updates_manager", None)
    if manager is None:
        return False
    profile = args.data_root / "updates/settings/installation.json"
    existed = profile.exists()
    result = run_command(
        [str(release / "runtime/bin/node"), str(release / "app/node_modules/@notenv/updates/dist/provision.js"), str(args.data_root), manager, str(release),
         *(["--provision-trust"] if getattr(args, "provision_update_trust", False) else [])],
        check=False, capture_output=True, timeout=30,
        env={"PATH": os.environ.get("PATH", "/usr/bin:/bin")},
    )
    if result.returncode:
        detail = provisioning_failure(result.stderr)
        detail["worker_exit_code"] = result.returncode if type(result.returncode) is int and -255 <= result.returncode <= 255 else None
        raise UpdateProvisioningError(detail)
    try:
        receipt = json.loads(result.stdout)
        if receipt.get("values_returned") is not False or type(receipt.get("changed")) is not bool:
            raise ValueError()
    except (ValueError, AttributeError):
        raise RuntimeError("update-provisioning-response-invalid") from None
    return not existed or receipt["changed"]


def provision_existing_update_trust(args: argparse.Namespace, state: Path, previous: dict[str, Any] | None) -> dict[str, Any]:
    """Provision only public trust from a verified release; never activate its bytes."""
    if previous is None or previous["state"] != "complete":
        raise RuntimeError("update-trust-completed-installation-required")
    source = release_root()
    source_hash = verify_release(source)
    source_info = metadata(source)
    verify_native_signing(source, source_info)
    if not (source / "update-trust.json").is_file():
        raise RuntimeError("update-trust-asset-required")
    validate_updates_manager(args)
    installed = read_public_record(state / "installed.json")
    current = activation_target(args.data_root, "current")
    if current is None:
        raise RuntimeError("update-trust-completed-installation-required")
    current_info = metadata(Path(current))
    manifest = verify_release(Path(current))
    verify_native_signing(Path(current), current_info)
    expected = {"installation_root": str(args.data_root.resolve()),
                "version": current_info["version"], "source_commit": current_info["source_commit"],
                "release_manifest_sha256": manifest, "bin_dir": str(args.bin_dir.resolve()),
                "service_path": str(args.service_path.absolute()), "service_mode": args.service_mode}
    if any(installed.get(name) != value for name, value in expected.items()):
        raise RuntimeError("update-trust-installation-mismatch")
    ready, _, _ = verify_install(args)
    if not ready:
        raise RuntimeError("update-trust-installation-unavailable")
    args.provision_update_trust = True
    changed = provision_machine_updates(args, source)
    return {"schema_version": 1, "operation": "provision-update-trust", "changed": changed,
            "version": current_info["version"], "source_commit": current_info["source_commit"],
            "provisioned_from": {"version": source_info["version"], "source_commit": source_info["source_commit"],
                                 "release_manifest_sha256": source_hash},
            "application_changed": False, "service_restarted": False, "values_returned": False}


def scheduler_profile(args: argparse.Namespace) -> dict[str, Any] | None:
    path = args.data_root / "updates/settings/installation.json"
    if not path.exists() and not path.is_symlink():
        return None
    value = read_public_record(path)
    if (value.get("schema_version") != 1 or value.get("kind") != "installed"
            or value.get("installation_root") != str(args.data_root.resolve())):
        raise RuntimeError("update-installation-owner-conflict")
    uuid.UUID(value["installation_id"])
    return value


def scheduler_definitions(args: argparse.Namespace, release: Path) -> dict[Path, str]:
    replacements = {
        "__CURRENT__": str(args.data_root / "current"),
        "__UPDATE_PROFILE__": str(args.data_root / "updates/settings/installation.json"),
        "__HOME__": str(Path.home()),
    }
    macos = platform.system() == "Darwin"
    names = (("update-launchd.plist", "com.ctx9.notenv-update.plist"),) if macos else (
        ("update-systemd.service", "notenv-update.service"),
        ("update-systemd.timer", "notenv-update.timer"),
    )
    definitions = {}
    for template, name in names:
        rendered = (release / "service" / template).read_text(encoding="utf-8")
        for marker, value in replacements.items():
            if any(ord(character) < 32 for character in value) or (not macos and "$" in value):
                raise RuntimeError("update-scheduler-path-unsafe")
            escaped = xml_escape(value) if macos else value.replace("\\", "\\\\").replace('"', '\\"').replace("%", "%%")
            rendered = rendered.replace(marker, escaped)
        definitions[args.service_path.parent / name] = rendered
    return definitions


def scheduler_registration(args: argparse.Namespace, profile: dict[str, Any], definitions: dict[Path, str]) -> dict[str, Any]:
    return {
        "schema_version": 1,
        "installation_id": profile["installation_id"],
        "installation_root": str(args.data_root.resolve()),
        "platform": "darwin" if platform.system() == "Darwin" else "linux",
        "definitions": {str(path): hashlib.sha256(content.encode()).hexdigest() for path, content in definitions.items()},
    }


def validate_scheduler(args: argparse.Namespace, release: Path) -> None:
    if args.service_mode != "install":
        return
    profile = scheduler_profile(args)
    selected = profile and profile.get("manager") == "standalone"
    if args.service_mode != "install" or not (selected or getattr(args, "updates_manager", None) == "standalone"):
        return
    definitions = scheduler_definitions(args, release)
    for path, content in definitions.items():
        if path.parent.exists():
            parent = path.parent.lstat()
            if not stat.S_ISDIR(parent.st_mode) or parent.st_uid != os.getuid() or parent.st_mode & 0o022 or path.parent.resolve() != path.parent:
                raise RuntimeError("update-scheduler-path-unsafe")
        if path.exists() or path.is_symlink():
            check_owned(path)
            if path.stat().st_size > 65536 or path.read_text(encoding="utf-8") != content:
                raise RuntimeError("update-scheduler-conflict")
    record = args.data_root / "updates/settings/scheduler.json"
    if record.exists() or record.is_symlink():
        value = read_public_record(record)
        expected = scheduler_registration(args, profile, definitions) if profile else None
        if expected is None or {key: value.get(key) for key in expected} != expected or not isinstance(value.get("registered"), bool):
            raise RuntimeError("update-scheduler-conflict")
    elif scheduler_present():
        raise RuntimeError("update-scheduler-owner-unrecorded")


def scheduler_active() -> bool:
    command = (["launchctl", "print", f"gui/{os.getuid()}/com.ctx9.notenv-update"]
               if platform.system() == "Darwin" else
               ["systemctl", "--user", "is-active", "--quiet", "notenv-update.timer"])
    return run_command(command, check=False, capture_output=True).returncode == 0


def scheduler_present() -> bool:
    if platform.system() == "Darwin":
        return scheduler_active()
    result = run_command(
        ["systemctl", "--user", "show", "--property=LoadState", "--value", "notenv-update.service", "notenv-update.timer"],
        check=False, capture_output=True, text=True,
    )
    states = result.stdout.split()
    if result.returncode or len(states) != 2:
        raise RuntimeError("update-scheduler-state-unavailable")
    return any(state != "not-found" for state in states)


def install_update_scheduler(args: argparse.Namespace, release: Path) -> bool:
    profile = scheduler_profile(args)
    if args.service_mode != "install" or not profile or profile.get("manager") != "standalone":
        return False
    validate_scheduler(args, release)
    definitions = scheduler_definitions(args, release)
    record = args.data_root / "updates/settings/scheduler.json"
    prior = read_public_record(record) if record.exists() else None
    registration = scheduler_registration(args, profile, definitions)
    changed = False
    for path, content in definitions.items():
        if not path.exists():
            ensure_service_directory(path.parent)
            descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
            with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
                handle.write(content)
                handle.flush()
                os.fsync(handle.fileno())
            changed = True
    # Retain intent before registration. A retry may acknowledge an already loaded
    # matching job, but must never restart the updater executing this installation.
    if prior is None:
        write_public_record(record, {**registration, "registered": False})
    active = scheduler_active()
    if not active:
        if platform.system() == "Darwin":
            run_command(["launchctl", "bootstrap", f"gui/{os.getuid()}", str(next(iter(definitions)))], check=True, capture_output=True)
        else:
            run_command(["systemctl", "--user", "daemon-reload"], check=True, capture_output=True)
            run_command(["systemctl", "--user", "enable", "--now", "notenv-update.timer"], check=True, capture_output=True)
        changed = True
    if prior != {**registration, "registered": True}:
        write_public_record(record, {**registration, "registered": True})
        changed = True
    return changed


def uninstall_update_scheduler(args: argparse.Namespace) -> bool:
    record = args.data_root / "updates/settings/scheduler.json"
    if not record.exists() and not record.is_symlink():
        return False
    profile = scheduler_profile(args)
    if not profile or profile.get("manager") != "standalone":
        raise RuntimeError("update-scheduler-conflict")
    current = args.data_root / "current"
    validate_scheduler(args, current)
    if platform.system() == "Darwin":
        if scheduler_active():
            run_command(["launchctl", "bootout", f"gui/{os.getuid()}/com.ctx9.notenv-update"], check=True, capture_output=True)
    else:
        run_command(["systemctl", "--user", "disable", "--now", "notenv-update.timer"], check=True, capture_output=True)
        run_command(["systemctl", "--user", "stop", "notenv-update.service"], check=True, capture_output=True)
    for path in scheduler_definitions(args, current):
        path.unlink(missing_ok=True)
    record.unlink()
    if platform.system() != "Darwin":
        run_command(["systemctl", "--user", "daemon-reload"], check=True, capture_output=True)
    return True


def validate_updates_manager(args: argparse.Namespace) -> None:
    manager = getattr(args, "updates_manager", None)
    profile = args.data_root / "updates/settings/installation.json"
    if manager is None or not profile.exists():
        return
    check_owned(profile)
    if profile.stat().st_size > 262144:
        raise RuntimeError("update-configuration-invalid")
    value = json.loads(profile.read_text(encoding="utf-8"))
    if value.get("manager") != manager or value.get("kind") != "installed" or value.get("installation_root") != str(args.data_root.resolve()):
        raise RuntimeError("update-installation-owner-conflict")


def activate(args: argparse.Namespace, transaction: dict[str, Any]) -> bool:
    source = release_root()
    release_hash = verify_release(source)
    info = metadata(source)
    verify_native_signing(source, info)
    version_dir = args.data_root / "versions" / info["version"]
    current = args.data_root / "current"
    previous = args.data_root / "previous"
    args.data_root.mkdir(parents=True, exist_ok=True)
    (args.data_root / "versions").mkdir(parents=True, exist_ok=True)
    args.bin_dir.mkdir(parents=True, exist_ok=True)
    if version_dir.exists():
        installed_info = metadata(version_dir)
        if verify_release(version_dir) != release_hash:
            raise RuntimeError("installed version identity conflicts with release")
        verify_native_signing(version_dir, installed_info)
    else:
        pending = version_dir.with_name(f".{version_dir.name}.pending-{os.getpid()}")
        if pending.exists():
            shutil.rmtree(pending)
        shutil.copytree(source, pending, symlinks=False)
        if verify_release(pending) != release_hash:
            raise RuntimeError("staged release identity conflicts with release")
        pending_info = metadata(pending)
        verify_native_signing(pending, pending_info)
        pending.replace(version_dir)
    updates_changed = provision_machine_updates(args, version_dir)
    replacement = confirm_machine_handoff(args, version_dir, info, release_hash)
    args.machine_replacement = replacement
    if replacement is None:
        verify_macos_custody_before_activation(version_dir, args.data_root, rename=transaction.get("rename") is not None and not transaction.get("rename_complete"))
    else:
        transaction["machine_replacement"] = True
        write_activation(args.activation_state, transaction)
    renamed = migrate_previous_installation(args, version_dir, transaction)
    if replacement is not None and not renamed:
        commit_machine_handoff(args, replacement)
    changed = not (current.is_symlink() and current.resolve() == version_dir.resolve())
    if changed:
        if transaction["before_current"] is not None:
            atomic_link(Path(transaction["before_current"]), previous)
        atomic_link(version_dir, current)
    for command, relative_target in COMMAND_TARGETS.items():
        destination = args.bin_dir / command
        if destination.exists() and not destination.is_symlink():
            raise RuntimeError(f"refusing to replace unrelated command: {destination}")
        expected = current / relative_target
        if not destination.is_symlink() or destination.resolve() != expected.resolve():
            atomic_link(expected, destination)
            changed = True
    if args.service_mode == "install":
        service_changed = install_service(current, args.data_root, args.service_path,
            force=changed or updates_changed or (transaction["resumed"] and not args.resume_admission))
        changed = changed or service_changed
        changed = install_update_scheduler(args, current) or changed
    return changed or renamed or updates_changed


def plan_activation(args: argparse.Namespace) -> tuple[bool, dict[str, Any], str]:
    validate_updates_manager(args)
    if platform.system() == "Linux" and not os.access("/bin/ps", os.X_OK):
        raise RuntimeError("process-tool-unavailable: install procps before activation")
    source = release_root()
    release_hash = verify_release(source)
    info = metadata(source)
    verify_native_signing(source, info)
    validate_scheduler(args, source)
    version_dir = args.data_root / "versions" / info["version"]
    current = args.data_root / "current"
    if version_dir.exists():
        if verify_release(version_dir) != release_hash:
            raise RuntimeError("installed version identity conflicts with release")
        verify_native_signing(version_dir, metadata(version_dir))
    for command_name in COMMAND_TARGETS:
        destination = args.bin_dir / command_name
        if (destination.is_symlink() and not owned_link(destination, args.data_root)) or (destination.exists() and not destination.is_symlink()):
            raise RuntimeError(f"refusing to replace unrelated command: {destination}")
    changed = not (current.is_symlink() and current.resolve() == version_dir.resolve())
    return changed, info, release_hash


def verify_install(args: argparse.Namespace) -> tuple[bool, list[str], dict[str, Any] | None]:
    current = args.data_root / "current"
    errors: list[str] = []
    info: dict[str, Any] | None = None
    if not current.is_symlink():
        errors.append("current release is missing")
    else:
        try:
            info = metadata(current)
            verify_release(current)
            verify_native_signing(current, info)
        except (OSError, ValueError, RuntimeError) as error:
            errors.append(str(error))
    for command, relative_target in COMMAND_TARGETS.items():
        destination = args.bin_dir / command
        if not owned_link(destination, args.data_root) or destination.resolve() != (current / relative_target).resolve():
            errors.append(f"command ownership invalid: {command}")
    if args.service_mode == "install" and not service_state():
        errors.append("broker service is not active")
    if args.service_mode == "install" and info is not None:
        try:
            profile = scheduler_profile(args)
            if profile and profile.get("manager") == "standalone":
                validate_scheduler(args, current)
                record = read_public_record(args.data_root / "updates/settings/scheduler.json")
                if not record.get("registered") or not scheduler_active():
                    errors.append("update scheduler is not active")
        except (OSError, ValueError, RuntimeError) as error:
            errors.append(str(error))
    return not errors, errors, info


def rollback(args: argparse.Namespace, transaction: dict[str, Any]) -> bool:
    current = args.data_root / "current"
    previous = args.data_root / "previous"
    if transaction["before_current"] is None or transaction["before_previous"] is None:
        raise RuntimeError("an exact previous release is unavailable")
    current_target = Path(transaction["before_current"])
    previous_target = Path(transaction["before_previous"])
    verify_release(previous_target)
    verify_native_signing(previous_target, metadata(previous_target))
    validate_scheduler(args, previous_target)
    if platform.system() == "Darwin":
        if metadata(previous_target).get("macos_machine_custody") != "hardware-sealed-v1":
            raise RuntimeError("rollback-native-custody-incompatible-current-release-preserved")
        verify_macos_custody_before_activation(previous_target, args.data_root, rename=False)
    atomic_link(previous_target, current)
    atomic_link(current_target, previous)
    if args.service_mode == "install":
        install_service(current, args.data_root, args.service_path, force=True)
    return True


def uninstall(args: argparse.Namespace) -> bool:
    changed = uninstall_update_scheduler(args) if args.service_mode == "install" else False
    if args.service_mode == "install" and args.service_path.exists():
        active = service_state()
        if platform.system() == "Darwin":
            if active:
                run_command(
                    ["launchctl", "bootout", f"gui/{os.getuid()}", str(args.service_path)], check=True, capture_output=True
                )
        else:
            run_command(
                ["systemctl", "--user", "disable", "--now", "notenv-broker.service"],
                check=True,
                capture_output=True,
            )
        args.service_path.unlink(missing_ok=True)
        changed = True
    for command in COMMAND_TARGETS:
        path = args.bin_dir / command
        if owned_link(path, args.data_root):
            path.unlink()
            changed = True
    for name in ("current", "previous"):
        path = args.data_root / name
        if path.is_symlink():
            path.unlink()
            changed = True
    return changed


def parser() -> argparse.ArgumentParser:
    default_data, default_bin, default_service = default_paths()
    result = argparse.ArgumentParser()
    modes = result.add_mutually_exclusive_group()
    modes.add_argument("--dry-run", action="store_true")
    modes.add_argument("--verify", action="store_true")
    modes.add_argument("--rollback", action="store_true")
    modes.add_argument("--uninstall", action="store_true")
    modes.add_argument("--prepare-machine-replacement", action="store_true")
    modes.add_argument("--cancel-admission", metavar="OPERATION_UUID", help="Cancel an exact interrupted admission only when no effects started")
    modes.add_argument("--resume-admission", metavar="OPERATION_UUID", help="Explicitly resume the exact interrupted admitted installation after effects started")
    modes.add_argument("--provision-update-trust-only", action="store_true", help="Provision verified public trust for an existing completed installation without changing application bytes or services")
    result.add_argument("--renew-machine-replacement", action="store_true", help="Renew a staged public request during explicit preparation")
    result.add_argument("--deployment", help="Deployment slug for explicit machine replacement preparation")
    result.add_argument("--data-root", type=Path, default=default_data)
    result.add_argument("--bin-dir", type=Path, default=default_bin)
    result.add_argument("--service-path", type=Path, default=default_service)
    result.add_argument("--service-mode", choices=("install", "skip"), default="install")
    result.add_argument("--updates-manager", choices=("standalone", "fleet"), help="Provision this installation's update ownership without enabling automatic activation")
    result.add_argument("--provision-update-trust", action="store_true", help="Explicitly provision an unconfigured profile from this verified release's public trust asset")
    result.add_argument("--broker-admission", action="store_true", help="Require a locked broker admission fence before an update")
    result.add_argument("--update-descriptor", metavar="SHA256", help="Require fresh broker authorization for this staged descriptor before effects")
    result.add_argument("--update-coordinator", metavar="OPERATION_UUID", help="Bind one exact external coordinator before admission or effects")
    result.add_argument("--update-trigger", choices=("manual", "automatic"), default="manual", help="Bind update intent to the final policy decision")
    result.add_argument("--drain-timeout", type=int, default=0, help="Wait at most this many seconds for existing work, otherwise defer before effects")
    result.add_argument("--json", action="store_true")
    return result


def main() -> int:
    args = parser().parse_args()
    if args.drain_timeout < 0 or args.drain_timeout > 300 or (args.drain_timeout and not args.broker_admission):
        parser().error("--drain-timeout requires --broker-admission and must be between 0 and 300")
    if args.broker_admission and (args.verify or args.rollback or args.uninstall or args.prepare_machine_replacement or args.cancel_admission):
        parser().error("--broker-admission is valid only for install or dry-run")
    if args.resume_admission and not args.broker_admission:
        parser().error("--resume-admission requires --broker-admission")
    if args.update_descriptor and (not re.fullmatch(r"[a-f0-9]{64}", args.update_descriptor) or not (args.broker_admission or args.cancel_admission)):
        parser().error("--update-descriptor requires an exact SHA256 and broker admission or cancellation")
    if args.update_coordinator:
        try:
            uuid.UUID(args.update_coordinator)
        except ValueError:
            parser().error("update coordinator requires an operation UUID")
        if not args.update_descriptor:
            parser().error("--update-coordinator requires --update-descriptor")
    if args.update_trigger == "automatic" and not args.update_coordinator:
        parser().error("automatic updates require --update-coordinator")
    if args.cancel_admission or args.resume_admission:
        try:
            uuid.UUID(args.cancel_admission or args.resume_admission)
        except (ValueError, AttributeError):
            parser().error("admission recovery requires an operation UUID")
    if args.updates_manager is not None and (args.verify or args.rollback or args.uninstall or args.prepare_machine_replacement or args.cancel_admission):
        parser().error("--updates-manager is valid only for installation or dry-run")
    if args.provision_update_trust and (args.updates_manager is None or args.broker_admission):
        parser().error("--provision-update-trust requires explicit --updates-manager and ordinary verified installation")
    if args.provision_update_trust_only and (args.updates_manager is None or args.broker_admission or args.provision_update_trust):
        parser().error("--provision-update-trust-only requires explicit --updates-manager and no activation options")
    if args.renew_machine_replacement and not args.prepare_machine_replacement:
        parser().error("--renew-machine-replacement requires --prepare-machine-replacement")
    args.data_root = args.data_root.absolute()
    args.bin_dir = args.bin_dir.absolute()
    args.service_path = args.service_path.absolute()
    operation = "cancel-admission" if args.cancel_admission else "prepare-machine-replacement" if args.prepare_machine_replacement else "dry-run" if args.dry_run else "rollback" if args.rollback else "uninstall" if args.uninstall else "verify" if args.verify else "install"
    mutate = not (args.dry_run or args.verify)
    transaction: dict[str, Any] | None = None
    resumed = False
    admission_release: str | None = None
    try:
        with ExitStack() as locks:
            state = locks.enter_context(activation_lock(args.data_root, mutate=mutate))
            args.activation_state = state
            previous_operation = read_activation(state)
            if args.provision_update_trust_only:
                assert state is not None
                receipt = provision_existing_update_trust(args, state, previous_operation)
                print(json.dumps(receipt, sort_keys=True))
                return 0
            if args.cancel_admission:
                assert state is not None
                if (previous_operation is None or previous_operation["operation_ref"] != args.cancel_admission
                    or previous_operation["request"].get("release_manifest_sha256") != verify_release(release_root())
                    or previous_operation["request"].get("update_descriptor_sha256") != args.update_descriptor
                    or previous_operation["request"].get("update_coordinator_ref") != args.update_coordinator
                    or (args.update_descriptor and previous_operation["request"].get("update_trigger") != args.update_trigger)):
                    raise RuntimeError("update-admission-operation-mismatch")
                admission_profile(args)
                receipt = defer_before_effects(args, state, previous_operation, "operator-cancelled")
                receipt["operation"] = "cancel-admission"
                print(json.dumps(receipt, sort_keys=True) if args.json else "Notenv update cancelled before effects")
                return 0 if receipt["admission_release"] == "confirmed" else 1
            if not mutate and previous_operation and previous_operation["state"] != "complete":
                raise RuntimeError("activation-incomplete: repeat the original installer command")
            paths = previous_installation_paths(args)
            if operation in ("install", "dry-run", "prepare-machine-replacement") and paths is not None and paths["data"].exists() and not (previous_operation and previous_operation.get("rename_complete")):
                locks.enter_context(activation_lock(paths["data"], mutate=mutate))
            args.rename_plan = previous_installation_plan(args, previous_operation) if operation in ("install", "dry-run", "prepare-machine-replacement") else None
            if args.prepare_machine_replacement:
                _, info, release_hash = plan_activation(args)
                if previous_operation and previous_operation["state"] != "complete":
                    if previous_operation["state"] == "applying":
                        raise RuntimeError("activation-outcome-unknown: establish prior owner and helper exit before recovery")
                    if previous_operation["request"].get("release_manifest_sha256") != release_hash:
                        raise RuntimeError("activation-request-conflict")
                receipt = prepare_machine_handoff(args, info, release_hash)
                payload = {**receipt, "component": "notenv", "operation": operation, "changed": True, "installation_root": str(args.data_root), "version": info["version"], "source_commit": info["source_commit"]}
                print(json.dumps(payload, sort_keys=True) if args.json else f"Approve machine replacement, then repeat the signed installer:\n{receipt['enrollment_url']}")
                return 0
            if mutate:
                assert state is not None
                source = release_root()
                if operation == "install":
                    _, source_info, release_hash = plan_activation(args)
                    if args.broker_admission and not args.resume_admission:
                        prepare_broker_admission(args, previous_operation)
                else:
                    release_hash = verify_release(source)
                    source_info = metadata(source)
                    verify_native_signing(source, source_info)
                if operation == "rollback" and not (previous_operation and previous_operation["state"] != "complete"):
                    target = activation_target(args.data_root, "previous")
                    if activation_target(args.data_root, "current") is None or target is None:
                        raise RuntimeError("an exact previous release is unavailable")
                    verify_release(Path(target))
                    verify_native_signing(Path(target), metadata(Path(target)))
                    if platform.system() == "Darwin" and metadata(Path(target)).get("macos_machine_custody") != "hardware-sealed-v1":
                        raise RuntimeError("rollback-native-custody-incompatible-current-release-preserved")
                coordinator = check_update_coordinator(args, previous_operation, source_info, release_hash)
                transaction, resumed = begin_activation(args, state, operation, source_info, release_hash)
                if coordinator is not None:
                    write_public_record(args.data_root / "updates/apply/operation.json", {
                        **coordinator, "installer_operation_ref": transaction["operation_ref"],
                    })
            try:
                info: dict[str, Any] | None = None
                if args.broker_admission and not args.dry_run:
                    assert transaction is not None and state is not None
                    if args.resume_admission:
                        resume_admitted_service(args, transaction)
                    try:
                        admitted = await_broker_admission(args, transaction)
                    except (OSError, ValueError, RuntimeError):
                        if transaction.get("effects_state") != "not-started":
                            raise
                        receipt = defer_before_effects(args, state, transaction, "admission-unavailable")
                        print(json.dumps(receipt, sort_keys=True) if args.json else "Notenv update deferred: admission unavailable")
                        return 0 if receipt["admission_release"] == "confirmed" else 1
                    if not admitted:
                        if transaction.get("effects_state") != "not-started":
                            raise RuntimeError("update-admission-recovery-required")
                        receipt = defer_before_effects(args, state, transaction, "busy")
                        print(json.dumps(receipt, sort_keys=True) if args.json else "Notenv update deferred: existing work")
                        return 0 if receipt["admission_release"] == "confirmed" else 1
                    if args.update_descriptor and transaction.get("effects_state") == "not-started":
                        try:
                            decision = authorize_broker_update(args, transaction)
                            entered = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
                            validate_update_authorization(args, transaction, decision, entered)
                        except (OSError, ValueError, RuntimeError):
                            receipt = defer_before_effects(args, state, transaction, "authorization-unavailable")
                            print(json.dumps(receipt, sort_keys=True) if args.json else "Notenv update deferred: authorization unavailable")
                            return 0 if receipt["admission_release"] == "confirmed" else 1
                        transaction.update(authorization=decision, authorized_effects_at=entered)
                    transaction["effects_state"] = "started"
                    write_activation(state, transaction)
                if args.dry_run:
                    would_change, info, _ = plan_activation(args)
                    if args.rename_plan is not None:
                        args.rename_plan["native_candidates"] = None if platform.system() == "Darwin" else migrate_native_metadata(release_root(), dry_run=True)
                        would_change = True
                    changed = False
                    ready, errors = True, []
                elif args.rollback:
                    assert transaction is not None
                    changed = rollback(args, transaction)
                elif args.uninstall:
                    changed = uninstall(args)
                elif args.verify:
                    changed = False
                else:
                    assert transaction is not None
                    changed = activate(args, transaction)
                if not args.dry_run:
                    ready, errors, info = verify_install(args) if not args.uninstall else (True, [], None)
                if transaction is not None and ready and operation == "install":
                    finish_previous_installation(args, transaction)
                    if platform.system() == "Darwin":
                        handoff = read_machine_handoff(args, info, release_hash)
                        if handoff is not None and handoff["state"] != "complete":
                            handoff["state"] = "complete"
                            write_public_record(handoff_directory(args, release_hash) / "handoff.json", handoff)
                if transaction is not None:
                    assert state is not None
                    if args.broker_admission and ready:
                        profile = admission_profile(args)
                        identity = await_broker_update_identity(args, profile)
                        if identity.get("current_version") != source_info["version"]:
                            raise RuntimeError("update-broker-readiness-failed")
                        transaction.update(effects_state="complete", outcome="installed")
                    if ready and operation == "install":
                        write_public_record(state / "installed.json", {
                            "schema_version": 1, "operation_ref": transaction["operation_ref"],
                            "installation_root": str(args.data_root.resolve()),
                            **{name: transaction["request"][name] for name in (
                                "version", "source_commit", "release_manifest_sha256", "bin_dir", "service_path", "service_mode")},
                        })
                    transaction["state"] = "complete" if ready else "incomplete"
                    write_activation(state, transaction)
            except BaseException as error:
                if transaction is not None and transaction["state"] != "complete":
                    assert state is not None
                    # subprocess.run reaps children for ordinary failures. Cancellation
                    # or process death is not that proof, even if the OS lock is free.
                    transaction["state"] = "incomplete" if isinstance(error, Exception) and not isinstance(error, subprocess.TimeoutExpired) else "applying"
                    if isinstance(error, UpdateProvisioningError):
                        transaction["last_provisioning_failure"] = error.detail
                    write_activation(state, transaction)
                raise
            if args.broker_admission and transaction is not None and transaction["state"] == "complete":
                admission_release = release_broker_admission()
                if admission_release != "confirmed":
                    ready = False
                    errors.append("update-admission-release-pending")
        payload = {
            "schema_version": 1,
            "component": "notenv",
            "operation": operation,
            "operation_ref": transaction["operation_ref"] if transaction else None,
            "resumed": resumed,
            "mutation_outcome": "complete" if transaction and transaction["state"] == "complete" else "incomplete" if transaction else "not-started",
            "ready": ready,
            "changed": changed,
            **({"state": "installed" if admission_release == "confirmed" else "installed-admission-pending", "admission_release": admission_release} if args.broker_admission and transaction is not None else {}),
            **({"would_change": would_change} if args.dry_run else {}),
            **({"admission_required": True, "admission_checked": False} if args.dry_run and args.broker_admission else {}),
            **({"rename": {"previous_version": args.rename_plan["identity"]["version"], "storage_moves": len(args.rename_plan["moves"]), "native_candidates": args.rename_plan.get("native_candidates")}} if args.dry_run and args.rename_plan is not None else {}),
            "version": info.get("version") if info else None,
            "source_commit": info.get("source_commit") if info else None,
            "installation_root": str(args.data_root),
            "errors": errors,
            "values_returned": False,
        }
        print(json.dumps(payload, sort_keys=True) if args.json else f"Notenv ready={ready}")
        return 0 if ready else 1
    except (OSError, ValueError, RuntimeError, subprocess.SubprocessError) as error:
        diagnostic = str(error) if isinstance(error, RuntimeError) else "activation-command-failed"
        payload = {"schema_version": 1, "component": "notenv", "operation": operation, "operation_ref": transaction["operation_ref"] if transaction else None, "resumed": resumed, "mutation_outcome": "incomplete" if transaction else "not-started", "ready": False, "changed": transaction is not None, "errors": [diagnostic], "values_returned": False}
        if isinstance(error, UpdateProvisioningError):
            payload["provisioning_failure"] = error.detail
        print(json.dumps(payload, sort_keys=True) if args.json else f"Notenv install failed: {diagnostic}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
