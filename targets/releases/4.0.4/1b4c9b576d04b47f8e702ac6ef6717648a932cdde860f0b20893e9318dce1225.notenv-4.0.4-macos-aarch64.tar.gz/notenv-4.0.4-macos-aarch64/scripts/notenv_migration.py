"""One-time native metadata migration; never request a stored secret value."""

from __future__ import annotations

import ctypes as c
import ctypes.util
import os
from pathlib import Path
from typing import Any, Callable


PREVIOUS_SERVICES = {
    "ctx9.secret-bindings.cli": "ctx9.notenv.cli",
    "secret-bindings-channel-identity": "notenv-channel-identity",
    "secret-bindings-machine-age-identity": "notenv-machine-age-identity",
    "secret-bindings-protected-unlock": "notenv-protected-unlock",
}
PREVIOUS_ATTRIBUTES = {
    "secret-bindings-provider": "notenv-provider",
    "secret-bindings-resource": "notenv-resource",
}


class NativeMigrationError(RuntimeError):
    """Fixed diagnostics only; provider errors may contain private metadata."""


class GList(c.Structure):
    pass


GList._fields_ = [("data", c.c_void_p), ("next", c.POINTER(GList)), ("previous", c.POINTER(GList))]


def renamed_attributes(attributes: dict[str, str]) -> dict[str, str] | None:
    cli = attributes.get("service") == "ctx9.secret-bindings.cli"
    provider = "secret-bindings-provider" in attributes
    if not cli and not provider:
        return None
    if any(previous in attributes and current in attributes for previous, current in PREVIOUS_ATTRIBUTES.items()):
        raise NativeMigrationError("native-metadata-attribute-conflict")
    renamed = {PREVIOUS_ATTRIBUTES.get(key, key): value for key, value in attributes.items()}
    field = "service" if cli else "notenv-provider"
    renamed[field] = PREVIOUS_SERVICES.get(renamed[field], renamed[field])
    return renamed


def migrate_linux_metadata(*, dry_run: bool) -> int:
    """Uses libsecret's metadata APIs with ALL, without UNLOCK or LOAD_SECRETS.

    Existing item IDs and their encrypted values remain unchanged. A locked or
    unavailable store is a checkpoint, never a reason to replace enrollment.
    """
    if not os.environ.get("DBUS_SESSION_BUS_ADDRESS"):
        os.environ["DBUS_SESSION_BUS_ADDRESS"] = f"unix:path=/run/user/{os.getuid()}/bus"
    try:
        secret = c.CDLL(ctypes.util.find_library("secret-1") or "libsecret-1.so.0")
        glib = c.CDLL(ctypes.util.find_library("glib-2.0") or "libglib-2.0.so.0")
        objects = c.CDLL(ctypes.util.find_library("gobject-2.0") or "libgobject-2.0.so.0")
    except OSError:
        raise NativeMigrationError("native-metadata-provider-unavailable") from None

    pointer = c.c_void_p
    error_pointer = c.POINTER(pointer)
    callback_type = c.CFUNCTYPE(None, pointer, pointer, pointer)

    def bind(library: Any, name: str, result: Any, arguments: list[Any]):
        function = getattr(library, name)
        function.restype = result
        function.argtypes = arguments
        return function

    new_table = bind(glib, "g_hash_table_new_full", pointer, [pointer, pointer, pointer, pointer])
    duplicate = bind(glib, "g_strdup", pointer, [c.c_char_p])
    insert = bind(glib, "g_hash_table_insert", c.c_int, [pointer, pointer, pointer])
    foreach = bind(glib, "g_hash_table_foreach", None, [pointer, callback_type, pointer])
    unref_table = bind(glib, "g_hash_table_unref", None, [pointer])
    free_list = bind(glib, "g_list_free", None, [c.POINTER(GList)])
    free_error = bind(glib, "g_error_free", None, [pointer])
    unref_object = bind(objects, "g_object_unref", None, [pointer])
    service_get = bind(secret, "secret_service_get_sync", pointer, [c.c_int, pointer, error_pointer])
    search = bind(secret, "secret_service_search_sync", c.POINTER(GList), [pointer, pointer, pointer, c.c_int, pointer, error_pointer])
    get_attributes = bind(secret, "secret_item_get_attributes", pointer, [pointer])
    get_locked = bind(secret, "secret_item_get_locked", c.c_int, [pointer])
    set_attributes = bind(secret, "secret_item_set_attributes_sync", c.c_int, [pointer, pointer, pointer, pointer, error_pointer])
    set_label = bind(secret, "secret_item_set_label_sync", c.c_int, [pointer, c.c_char_p, pointer, error_pointer])

    def table(values: dict[str, str]):
        value = new_table(c.cast(glib.g_str_hash, pointer), c.cast(glib.g_str_equal, pointer), c.cast(glib.g_free, pointer), c.cast(glib.g_free, pointer))
        if not value:
            raise NativeMigrationError("native-metadata-allocation-failed")
        for key, item in values.items():
            insert(value, duplicate(key.encode()), duplicate(item.encode()))
        return value

    def checked(function: Any, *arguments: Any):
        error = pointer()
        value = function(*arguments, c.byref(error))
        if error.value:
            free_error(error)
            raise NativeMigrationError("native-metadata-operation-failed")
        return value

    service = checked(service_get, 0, None)
    if not service:
        raise NativeMigrationError("native-metadata-provider-unavailable")
    criteria = table({})
    items = None
    pending: list[tuple[int, dict[str, str]]] = []
    targets: set[frozenset[tuple[str, str]]] = set()
    try:
        # 2 is SECRET_SEARCH_ALL. No session, unlock, or secret-loading flag.
        items = checked(search, service, None, criteria, 2, None)
        cursor = items
        while cursor:
            item = cursor.contents.data
            metadata = get_attributes(item)
            attributes: dict[str, str] = {}
            malformed: list[bool] = []

            @callback_type
            def collect(key: int, value: int, _context: int):
                try:
                    attributes[c.string_at(key).decode()] = c.string_at(value).decode()
                except UnicodeError:
                    malformed.append(True)

            try:
                foreach(metadata, collect, None)
            finally:
                unref_table(metadata)
            if malformed:
                raise NativeMigrationError("native-metadata-invalid")
            renamed = renamed_attributes(attributes)
            if renamed is not None:
                target = frozenset(renamed.items())
                if target in targets:
                    raise NativeMigrationError("native-metadata-target-conflict")
                targets.add(target)
                replacement = table(renamed)
                conflicts = None
                try:
                    conflicts = checked(search, service, None, replacement, 2, None)
                    if conflicts:
                        raise NativeMigrationError("native-metadata-target-conflict")
                finally:
                    unref_table(replacement)
                    conflict = conflicts
                    while conflict:
                        unref_object(conflict.contents.data)
                        conflict = conflict.contents.next
                    if conflicts:
                        free_list(conflicts)
                if not dry_run and get_locked(item):
                    raise NativeMigrationError("native-metadata-store-locked")
                pending.append((item, renamed))
            cursor = cursor.contents.next
        # Validate every item before changing any label or attribute.
        if not dry_run:
            for item, renamed in pending:
                replacement = table(renamed)
                try:
                    if not checked(set_label, item, b"Notenv", None):
                        raise NativeMigrationError("native-metadata-update-failed")
                    if not checked(set_attributes, item, None, replacement, None):
                        raise NativeMigrationError("native-metadata-update-failed")
                finally:
                    unref_table(replacement)
        return len(pending)
    finally:
        cursor = items
        while cursor:
            unref_object(cursor.contents.data)
            cursor = cursor.contents.next
        if items:
            free_list(items)
        unref_table(criteria)
        unref_object(service)


def plan_storage_moves(previous_data: Path, data_root: Path, previous_config: Path, config_root: Path, previous_state: Path, state_root: Path) -> list[tuple[Path, Path]]:
    """Public path plan only. Archived release closures stay at their original paths."""
    import stat

    def owned_directory(path: Path) -> None:
        metadata = path.lstat()
        if not stat.S_ISDIR(metadata.st_mode) or metadata.st_uid != os.getuid() or metadata.st_mode & 0o022:
            raise NativeMigrationError("rename-storage-unsafe")

    moves: list[tuple[Path, Path]] = []
    for source, destination in [(previous_config, config_root), (previous_state, state_root)]:
        if source == previous_data or not source.exists():
            continue
        owned_directory(source)
        if destination.exists() or destination.is_symlink():
            raise NativeMigrationError("rename-storage-target-conflict")
        moves.append((source, destination))
    if previous_data.exists():
        owned_directory(previous_data)
        if data_root.exists():
            owned_directory(data_root)
        for source in sorted(previous_data.iterdir()):
            # These closures and transaction records are immutable recovery evidence.
            if source.name in {"versions", "current", "previous", ".activation"}:
                continue
            if source.is_symlink():
                raise NativeMigrationError("rename-storage-unsafe")
            destination = data_root / source.name
            if destination.exists() or destination.is_symlink():
                raise NativeMigrationError("rename-storage-target-conflict")
            moves.append((source, destination))
    return moves


def apply_storage_moves(moves: list[tuple[Path, Path]], *, record: Callable[[Path, Path, str], None]) -> None:
    """Rename bytes within their existing owner custody, recording every checkpoint.

    The enclosing installer owns both installation locks and has stopped the old
    service. No file body, credential, cache entry, or encrypted value is read.
    Source absence plus destination presence allows the exact recorded step to
    resume. Neither a collision nor absence on both sides permits overwriting.
    """
    for source, destination in moves:
        source, destination = Path(source), Path(destination)
        source_present = source.exists() or source.is_symlink()
        destination_present = destination.exists() or destination.is_symlink()
        if source_present and destination_present:
            raise NativeMigrationError("rename-storage-target-conflict")
        if not source_present:
            if not destination_present:
                raise NativeMigrationError("rename-storage-step-uncertain")
            record(source, destination, "moved")
            continue
        destination.parent.mkdir(parents=True, mode=0o700, exist_ok=True)
        record(source, destination, "moving")
        # No cross-device copy fallback: identity custody must remain on this machine.
        try:
            source.rename(destination)
        except OSError:
            raise NativeMigrationError("rename-storage-move-failed") from None
        for parent in {source.parent, destination.parent}:
            descriptor = os.open(parent, os.O_RDONLY)
            try:
                os.fsync(descriptor)
            finally:
                os.close(descriptor)
        record(source, destination, "moved")
